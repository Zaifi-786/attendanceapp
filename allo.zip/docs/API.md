# API the frontend expects

The requirements document does not list routes, so these are the ones the frontend calls.
They are all in `src/api/`, one file per area, with the requirement number next to each call.
If your .NET controllers use different routes, change them in that one folder and nothing else.

## General rules

- Base path is `/api` (set with `VITE_API_BASE_URL`).
- Body and response are JSON, property names in camelCase (the ASP.NET Core default).
- Every call except `POST /api/auth/login` sends `Authorization: Bearer <token>` (AUTH-2).
- Dates are `yyyy-MM-dd`. Times are `HH:mm`. Date and time together are `yyyy-MM-ddTHH:mm:ss`, local office time, no time zone (NFR-3).
- Durations are whole minutes.
- Return **401** when the token is missing or expired. The frontend then goes to the sign-in page.
- Errors: normal ASP.NET `ProblemDetails` or `ValidationProblemDetails`. The frontend shows `detail`, `title` or the messages inside `errors`.
- If the API is on a different domain than the website, turn on CORS for the website's address.

## Sign in

| Call | Body / query | Returns | Req |
|---|---|---|---|
| `POST /auth/login` | `{ userName, password }` | `{ token, expiresAt, user: { id, userName, displayName, roles } }` | AUTH-1, AUTH-4 |
| `GET /auth/me` | | the same `user` object | AUTH-3 |

Only Admin users should get a token. Wrong password: 401. Locked out: 401 or 403 with a clear message.

## Employees, departments

| Call | Body / query | Returns | Req |
|---|---|---|---|
| `GET /employees` | `search, departmentId, status (Active/Inactive), page, pageSize` | `{ items: [Employee], total }` | EMP-3 |
| `GET /employees/{id}` | | `Employee` | |
| `POST /employees` | `{ employeeCode, name, departmentId, joinDate, deviceUserId }` | `Employee` | EMP-1 |
| `PUT /employees/{id}` | same as above | `Employee` | EMP-2, DEP-2 |
| `POST /employees/{id}/deactivate` | | | EMP-2 |
| `POST /employees/{id}/reactivate` | | | EMP-2 |
| `GET /departments` | | `[{ id, name, isActive, employeeCount }]` | DEP-1 |
| `POST /departments` | `{ name }` | | DEP-1 |
| `PUT /departments/{id}` | `{ name }` | | DEP-1 |
| `POST /departments/{id}/deactivate` and `/activate` | | | DEP-1 |

`Employee` = `{ id, employeeCode, name, departmentId, departmentName, joinDate, status, deviceUserId }`.
Employee code and device user ID must be unique. Answer 400 or 409 with a message if not.

## Shifts and assignments

| Call | Body / query | Returns | Req |
|---|---|---|---|
| `GET /shifts` | | `[{ id, name, startTime, endTime, breakMinutes, workingDays, isOvernight }]` | SHF-1 |
| `POST /shifts` | `{ name, startTime, endTime, breakMinutes, workingDays }` | | SHF-1 |
| `PUT /shifts/{id}` | same + `effectiveFrom` | | SHF-4 |
| `GET /shift-assignments` | `employeeId` | `[{ id, employeeId, shiftId, shiftName, fromDate, toDate }]` | SHF-2 |
| `POST /shift-assignments` | `{ employeeId, shiftId, fromDate, toDate }` | | SHF-2 |
| `POST /shift-assignments/bulk` | `{ shiftId, fromDate, toDate, departmentId }` or `{ ..., employeeIds }` | `{ assigned, skipped: [{ employeeId, employeeName, reason }] }` | SHF-3 |
| `DELETE /shift-assignments/{id}` | | | SHF-2 |

`workingDays`: 1 = Monday to 7 = Sunday. `toDate` can be null. `isOvernight` is true when the end time is earlier than the start time.
A new assignment that overlaps an existing one for the same employee must be refused (409).

## Settings and analysis

| Call | Body | Returns | Req |
|---|---|---|---|
| `GET /settings` | | `{ gracePeriodMinutes, flexiTimeCover }` | SET-1, SET-2 |
| `PUT /settings` | same | | SET-1, SET-2 |
| `POST /analysis/run` | `{ employeeId (optional), fromDate, toDate }` | `{ daysAnalyzed, daysSkippedNoShift }` | ANL-3, ANL-5 |

Saving settings must not change old results (SET-3). Only `analysis/run` recalculates.

## Reports

| Call | Query | Returns | Req |
|---|---|---|---|
| `GET /reports/daily` | `date, departmentId` | `[DailyRow]` | RPT-1 |
| `GET /reports/daily/{employeeId}/{date}` | | `DayDetail` | RPT-2 |
| `GET /reports/employee-period` | `employeeId, from, to` | `{ employee, from, to, days: [DailyRow], totals }` | RPT-3, RPT-7 |
| `GET /reports/dashboard` | `date` | see below | RPT-4 |
| `GET /reports/daily/export` | `date, departmentId, format (xlsx/pdf)` | the file | RPT-5 |
| `GET /reports/employee-period/export` | `employeeId, from, to, format` | the file | RPT-5 |
| `GET /punches/unmapped` | `from, to` | `[{ id, deviceName, deviceUserId, time, direction, floor }]` | RPT-6, DEV-8 |
| `GET /punches/unscheduled` | `from, to` | `[{ id, employeeId, employeeCode, employeeName, date, time, deviceName, direction }]` | RPT-6, ANL-7 |

**DailyRow**
```
{ employeeId, employeeCode, employeeName, department, shiftName,
  checkIn, checkOut, breakMinutes, presenceMinutes, workMinutes,
  overtimeMinutes, shortfallMinutes, shiftHoursStatus, alertCount, status }
```
`status` is one of `Present, Late, EarlyExit, MissingCheckOut, Absent`.
`shiftHoursStatus` is `Met`, `Short`, `Over` or `None`. In the period report each row also has `date`.

**totals** (period report)
```
{ daysWorked, workMinutes, overtimeMinutes, shortfallMinutes, breakMinutes,
  lateArrivals, earlyExits, missingPunches }
```
Totals are the sum of the days returned (RPT-7). The frontend shows them as sent and does not add anything up itself.

**DayDetail**
```
{ employee: { id, employeeCode, name, department },
  date,
  shift: { name, startTime, endTime, breakMinutes, isOvernight },     // null if no shift
  settingsUsed: { gracePeriodMinutes, flexiTimeCover, calculatedAt },
  rawPunches: [{ time, deviceName, direction, floor }],
  events:     [{ time, type, deviceName }],      // CheckIn, CheckOut, BreakStart, BreakEnd, Unclassified
  breaks:     [{ start, end, minutes }],
  alerts:     [{ type, time, message }],
  summary:    DailyRow }
```

**Dashboard**
```
{ date,
  totals: { present, absent, late, earlyExit, missingCheckOut },
  byDepartment: [{ department, present, absent, late, earlyExit, missingCheckOut }],
  trend: [{ date, present, absent, late }],          // last 30 days
  openAlertsByType: [{ type, count }] }
```
Absent means a scheduled shift with no punches.

## Devices and audit

| Call | Query | Returns | Req |
|---|---|---|---|
| `GET /devices/status` | | `[{ id, name, ip, direction, floor, enabled, lastSuccessfulSync, lastError, punchesToday, clockDriftSeconds }]` | DEV-10 |
| `GET /audit-log` | `entity (Employee/Shift/Settings), page, pageSize` | `{ items: [{ id, when, userName, entity, entityId, action, summary }], total }` | AUTH-5 |
