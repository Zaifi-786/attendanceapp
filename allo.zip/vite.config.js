import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')

  return {
    plugins: [react(), tailwindcss()],
    server: {
      port: 5173,
      // in dev, /api calls are forwarded to the .NET API so we don't need CORS locally
      proxy: {
        '/api': {
          target: env.VITE_DEV_API_TARGET || 'https://localhost:7001',
          changeOrigin: true,
          secure: false,
        },
      },
    },
  }
})
