# Attendance Management: Web App

React and Tailwind frontend for the Attendance Management System. Admin users only.
It talks to the ASP.NET Core API. The list of calls is in [docs/API.md](docs/API.md).

## What is in it

| Screen | Requirement |
|---|---|
| Sign in, route guard, sign out clears the session | AUTH-1, AUTH-3 |
| Dashboard (counts, by department, 30 day trend, open alerts) | RPT-4 |
| Daily report and day detail | RPT-1, RPT-2 |
| Employee period report with totals | RPT-3 |
| Excel and PDF buttons | RPT-5 |
| Unmapped and unscheduled punches | RPT-6, DEV-8 |
| Employees (search, filters, add, edit, deactivate) | EMP-1 to EMP-3 |
| Departments | DEP-1, DEP-2 |
| Shifts and shift assignment (one, department, selection) | SHF-1 to SHF-4 |
| Settings (grace period, flexi switch) | SET-1, SET-2 |
| Run analysis by hand | ANL-3, ANL-5 |
| Device status | DEV-10 |
| Audit log | AUTH-5 |

## Run it

You need Node 20 or newer.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:5173.

- With the real API: set `VITE_DEV_API_TARGET` in `.env.local` to where the .NET API runs. Dev server forwards `/api` there.
- Without the API (just to look around): set `VITE_USE_MOCK=true`, restart, and sign in with `admin` / `admin`.

## Build

```bash
npm run build
```

The finished site is in `dist/`. See [DEPLOYMENT.md](DEPLOYMENT.md) for how to put it on a server.

## Folder layout

```
src/
  api/          one file per area, all the API calls live here (plus mock.js for demo data)
  components/   layout, route guard, small shared pieces
  context/      sign-in state
  hooks/        useFetch
  pages/        one file per screen
  utils/        date and minute formatting
```

## Notes

- The token is kept in `sessionStorage`, so closing the tab signs you out. Signing out clears it.
- Any 401 from the API sends the user to the sign-in page.
- All times shown are the times the API sends (local office time). The app does no time zone conversion.
- Report totals come from the API. The app never adds up rows on its own, so the numbers match what is stored (RPT-7).
