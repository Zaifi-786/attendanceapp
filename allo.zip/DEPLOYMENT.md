# Deployment guide

The web app is a set of static files (HTML, JS, CSS). It does not need Node on the server.
You build it once, then copy the `dist` folder to any web server. It deploys on its own,
separate from the API and the device service (NFR-5).

## 1. Put the code on GitHub (section 11 of the requirements)

```bash
git init
git add .
git commit -m "Initial commit: React web app"
git branch -M main
git remote add origin https://github.com/<your-account>/attendance-web.git
git push -u origin main
```

Create the empty repository on github.com first (New repository, no README).

Add the client as a collaborator:

1. Open the repository on GitHub, then **Settings > Collaborators > Add people**.
2. Type `muhammadzeshawn.1@gmail.com` and choose **Write** (or Admin if they asked for it).
3. They get an email invite and must accept it.

If GitHub does not find the person by email, ask for their GitHub user name and add that instead.

Working rule for the team: do not commit to `main` directly. Make a branch, push it, open a pull request.

## 2. Choose the API address

The address is decided at build time. Vite copies it into the JavaScript, so if it changes you must build again.

| Setup | `VITE_API_BASE_URL` | What else |
|---|---|---|
| Site and API on the same domain (recommended) | `/api` | Web server forwards `/api` to the API. No CORS. |
| API on its own domain | `https://api.yourcompany.com/api` | Turn on CORS in the .NET API for the site's address. |

Create `.env.production` (not committed) with that one line:

```
VITE_API_BASE_URL=/api
```

Never put passwords or keys in these files. Everything in them is visible to anyone who opens the site.

## 3. Build

```bash
npm ci
npm run build
```

Copy everything inside `dist/` to the server.

## 4. Put it on a server

Pick one.

### Option A: IIS (Windows Server, fits the .NET stack)

1. Install the **URL Rewrite** module for IIS.
2. Create a folder, for example `C:\inetpub\attendance-web`, and copy the contents of `dist` into it.
   `web.config` is already included in the build. It sends page requests to `index.html`.
3. In IIS Manager add a site that points to that folder, bind it to port 443 with your certificate.
4. To use `/api` on the same domain, add **Application Request Routing**, or put the API in the same site as a
   child application under `/api`.
5. Browse to the site and refresh on a page other than the home page. If you get a 404, URL Rewrite is missing.

### Option B: Nginx (Linux)

```nginx
server {
    listen 443 ssl;
    server_name attendance.yourcompany.com;

    ssl_certificate     /etc/ssl/yourcompany/fullchain.pem;
    ssl_certificate_key /etc/ssl/yourcompany/privkey.pem;

    root /var/www/attendance-web;
    index index.html;

    # the API (Kestrel running on this machine or another one)
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # React Router: any other path gets index.html
    location / {
        try_files $uri /index.html;
    }

    # built files have a hash in the name, safe to cache for a long time
    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # but never cache the page itself, or users keep an old version
    location = /index.html {
        add_header Cache-Control "no-store";
    }
}

server {
    listen 80;
    server_name attendance.yourcompany.com;
    return 301 https://$host$request_uri;
}
```

Copy the build with:

```bash
rsync -av --delete dist/ user@server:/var/www/attendance-web/
sudo nginx -t && sudo systemctl reload nginx
```

### Option C: Azure Static Web Apps (or Netlify, Vercel)

- Connect the GitHub repository.
- Build command `npm run build`, output folder `dist`.
- Add `VITE_API_BASE_URL` in the host's environment variable settings.
- Because the API is on another domain here, use the full API address and enable CORS in the API.
- `public/staticwebapp.config.json` already handles the page fallback for Azure.

## 5. HTTPS and headers (AUTH-4)

- HTTPS only. Redirect port 80 to 443 and turn on HSTS.
- The API must also be HTTPS. A site on HTTPS cannot call an API on plain HTTP.
- Good headers to add at the web server: `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`,
  `Referrer-Policy: same-origin`.

## 6. Automatic build with GitHub Actions

`.github/workflows/build.yml` is already in the repository. On every push to `main` it installs, builds
and saves the `dist` folder as a download on the run page.

Set the API address there: **Settings > Secrets and variables > Actions > Variables > New variable**,
name `VITE_API_BASE_URL`.

To also upload to your server, add a last step to the workflow. For example with SSH:

```yaml
      - name: Upload to server
        run: |
          echo "${{ secrets.DEPLOY_KEY }}" > key && chmod 600 key
          rsync -av --delete -e "ssh -i key -o StrictHostKeyChecking=accept-new" dist/ \
            ${{ secrets.DEPLOY_USER }}@${{ secrets.DEPLOY_HOST }}:/var/www/attendance-web/
```

Store `DEPLOY_KEY`, `DEPLOY_USER` and `DEPLOY_HOST` under Settings > Secrets, not in the file.

## 7. Check after deploying

- Site opens on HTTPS and shows the sign-in page.
- Signing in as an Admin works. A non-admin account is refused.
- Refresh on `/reports/daily`. It must load, not show a 404.
- Open the browser's Network tab. Calls go to the right `/api/...` address and return 200.
- Sign out, then press the browser Back button. You must land on sign-in, not on a report.

## 8. Common problems

| Problem | Likely cause |
|---|---|
| Blank page, errors about `/assets/...` | Site is in a sub folder. Set `base` in `vite.config.js` and build again. |
| 404 when refreshing a page | Server is missing the "send everything to index.html" rule (section 4). |
| Network error or CORS message in the console | API is on another domain and CORS is not enabled, or the API address is wrong. |
| Everything returns 401 | Token expired, or API and site disagree on the JWT settings. Sign in again. |
| Old version still showing after deploy | `index.html` was cached. Use the no-store rule above. |
| Changed `.env` but nothing changed | Variables are read at build time. Run `npm run build` again. |

## 9. Rolling back

Keep the previous `dist` folder (or download an older one from the GitHub Actions run) and copy it back.
Nothing else needs to change because the web app has no database.
