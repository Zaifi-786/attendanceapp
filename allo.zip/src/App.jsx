import { Navigate, Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import ProtectedRoute from './components/ProtectedRoute'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import DailyReport from './pages/DailyReport'
import DayDetail from './pages/DayDetail'
import EmployeeReport from './pages/EmployeeReport'
import Punches from './pages/Punches'
import Employees from './pages/Employees'
import Departments from './pages/Departments'
import Shifts from './pages/Shifts'
import AssignShifts from './pages/AssignShifts'
import Settings from './pages/Settings'
import Analysis from './pages/Analysis'
import Devices from './pages/Devices'
import AuditLog from './pages/AuditLog'

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route element={<ProtectedRoute />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/reports/daily" element={<DailyReport />} />
          <Route path="/reports/daily/:employeeId/:date" element={<DayDetail />} />
          <Route path="/reports/employee" element={<EmployeeReport />} />
          <Route path="/punches" element={<Punches />} />
          <Route path="/employees" element={<Employees />} />
          <Route path="/departments" element={<Departments />} />
          <Route path="/shifts" element={<Shifts />} />
          <Route path="/shifts/assign" element={<AssignShifts />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/analysis" element={<Analysis />} />
          <Route path="/devices" element={<Devices />} />
          <Route path="/audit-log" element={<AuditLog />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
