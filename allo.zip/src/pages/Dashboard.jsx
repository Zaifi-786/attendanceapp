import { useState } from 'react'
import { getDashboard } from '../api/reports'
import useFetch from '../hooks/useFetch'
import { ErrorBox, Loading, PageHeader, Stat } from '../components/ui'
import { fmtDate, nice, today } from '../utils/format'

// RPT-4
export default function Dashboard() {
  const [date, setDate] = useState(today())
  const { data, loading, error, reload } = useFetch(() => getDashboard(date), [date])

  return (
    <div>
      <PageHeader title="Dashboard" subtitle={fmtDate(date)}>
        <input type="date" className="input" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
      </PageHeader>

      <ErrorBox message={error} onRetry={reload} />
      {loading && !data && <Loading />}

      {data && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
            <Stat label="Present" value={data.totals.present} color="text-green-600" />
            <Stat label="Absent" value={data.totals.absent} color="text-red-600" />
            <Stat label="Late" value={data.totals.late} color="text-amber-600" />
            <Stat label="Early exit" value={data.totals.earlyExit} color="text-amber-600" />
            <Stat label="Missing check-out" value={data.totals.missingCheckOut} color="text-red-600" />
          </div>

          <div>
            <h2 className="mb-2 font-semibold text-slate-700">By department</h2>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th>Department</th>
                    <th>Present</th>
                    <th>Absent</th>
                    <th>Late</th>
                    <th>Early exit</th>
                    <th>Missing check-out</th>
                  </tr>
                </thead>
                <tbody>
                  {data.byDepartment.map((d) => (
                    <tr key={d.department}>
                      <td className="font-medium">{d.department}</td>
                      <td>{d.present}</td>
                      <td>{d.absent}</td>
                      <td>{d.late}</td>
                      <td>{d.earlyExit}</td>
                      <td>{d.missingCheckOut}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <div className="card lg:col-span-2">
              <h2 className="mb-2 font-semibold text-slate-700">Last 30 days</h2>
              <TrendChart trend={data.trend} />
            </div>
            <div className="card">
              <h2 className="mb-2 font-semibold text-slate-700">Open alerts</h2>
              {data.openAlertsByType.length === 0 && <p className="text-sm text-slate-500">No open alerts.</p>}
              <ul className="divide-y divide-slate-100 text-sm">
                {data.openAlertsByType.map((a) => (
                  <li key={a.type} className="flex justify-between py-2">
                    <span>{nice(a.type)}</span>
                    <span className="font-semibold">{a.count}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// A plain SVG line chart, no chart library needed
function TrendChart({ trend }) {
  const W = 600
  const H = 200
  const pad = { l: 30, r: 10, t: 10, b: 24 }
  const max = Math.max(1, ...trend.flatMap((t) => [t.present, t.absent, t.late]))
  const x = (i) => pad.l + (i * (W - pad.l - pad.r)) / Math.max(1, trend.length - 1)
  const y = (v) => H - pad.b - (v * (H - pad.t - pad.b)) / max
  const line = (key) => trend.map((t, i) => `${i === 0 ? 'M' : 'L'}${x(i)},${y(t[key])}`).join(' ')

  const series = [
    { key: 'present', color: '#16a34a', label: 'Present' },
    { key: 'late', color: '#d97706', label: 'Late' },
    { key: 'absent', color: '#dc2626', label: 'Absent' },
  ]

  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
        {[0, 0.5, 1].map((f) => (
          <g key={f}>
            <line x1={pad.l} x2={W - pad.r} y1={y(max * f)} y2={y(max * f)} stroke="#e2e8f0" />
            <text x={pad.l - 4} y={y(max * f) + 3} textAnchor="end" fontSize="10" fill="#64748b">
              {Math.round(max * f)}
            </text>
          </g>
        ))}
        {series.map((s) => (
          <path key={s.key} d={line(s.key)} fill="none" stroke={s.color} strokeWidth="2" />
        ))}
        {trend.length > 0 && (
          <>
            <text x={pad.l} y={H - 6} fontSize="10" fill="#64748b">{fmtDate(trend[0].date)}</text>
            <text x={W - pad.r} y={H - 6} fontSize="10" fill="#64748b" textAnchor="end">
              {fmtDate(trend[trend.length - 1].date)}
            </text>
          </>
        )}
      </svg>
      <div className="mt-1 flex gap-4 text-xs text-slate-600">
        {series.map((s) => (
          <span key={s.key} className="flex items-center gap-1">
            <span className="inline-block h-2 w-3 rounded" style={{ background: s.color }} />
            {s.label}
          </span>
        ))}
      </div>
    </div>
  )
}
