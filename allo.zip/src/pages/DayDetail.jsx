import { Link, useParams } from 'react-router-dom'
import { getDayDetail } from '../api/reports'
import useFetch from '../hooks/useFetch'
import { ErrorBox, HoursBadge, Loading, PageHeader, StatusBadge, Badge } from '../components/ui'
import { fmtDate, fmtDateTime, fmtMinutes, nice } from '../utils/format'

// RPT-2: everything we know about one employee on one day
export default function DayDetail() {
  const { employeeId, date } = useParams()
  const { data, loading, error, reload } = useFetch(() => getDayDetail(employeeId, date), [employeeId, date])

  if (loading && !data) return <Loading />
  if (error) return <ErrorBox message={error} onRetry={reload} />
  if (!data) return null

  const s = data.summary

  return (
    <div className="space-y-5">
      <PageHeader
        title={`${data.employee.name} (${data.employee.employeeCode})`}
        subtitle={`${data.employee.department} - ${fmtDate(data.date)}`}
      >
        <Link to={`/reports/daily`} className="btn">Back to daily report</Link>
      </PageHeader>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="card">
          <h2 className="mb-2 font-semibold text-slate-700">Shift</h2>
          {data.shift ? (
            <dl className="grid grid-cols-2 gap-y-1 text-sm">
              <dt className="text-slate-500">Name</dt><dd>{data.shift.name}</dd>
              <dt className="text-slate-500">Time</dt>
              <dd>{data.shift.startTime} to {data.shift.endTime} {data.shift.isOvernight && <Badge color="blue">Overnight</Badge>}</dd>
              <dt className="text-slate-500">Official break</dt><dd>{fmtMinutes(data.shift.breakMinutes)}</dd>
            </dl>
          ) : (
            <p className="text-sm text-slate-500">No shift on this day. Punches are shown as unscheduled.</p>
          )}
        </div>

        <div className="card">
          <h2 className="mb-2 font-semibold text-slate-700">Calculated with</h2>
          {data.settingsUsed ? (
            <dl className="grid grid-cols-2 gap-y-1 text-sm">
              <dt className="text-slate-500">Grace period</dt><dd>{data.settingsUsed.gracePeriodMinutes} min</dd>
              <dt className="text-slate-500">Flexi time cover</dt><dd>{data.settingsUsed.flexiTimeCover ? 'On' : 'Off'}</dd>
              <dt className="text-slate-500">Calculated at</dt><dd>{fmtDateTime(data.settingsUsed.calculatedAt)}</dd>
            </dl>
          ) : (
            <p className="text-sm text-slate-500">Not analysed.</p>
          )}
        </div>
      </div>

      <div className="card">
        <div className="mb-2 flex items-center gap-2">
          <h2 className="font-semibold text-slate-700">Summary</h2>
          <StatusBadge status={s.status} />
        </div>
        <dl className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
          <Item label="Check-in" value={s.checkIn || '-'} />
          <Item label="Check-out" value={s.checkOut || '-'} />
          <Item label="Break" value={fmtMinutes(s.breakMinutes)} />
          <Item label="Presence" value={fmtMinutes(s.presenceMinutes)} />
          <Item label="Work time" value={fmtMinutes(s.workMinutes)} />
          <Item label="Overtime" value={fmtMinutes(s.overtimeMinutes)} />
          <Item label="Shortfall" value={fmtMinutes(s.shortfallMinutes)} />
          <Item label="Shift hours" value={<HoursBadge value={s.shiftHoursStatus} />} />
        </dl>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="Raw punches" empty="No punches." rows={data.rawPunches}
          head={['Time', 'Device', 'Direction', 'Floor']}
          render={(p) => [p.time, p.deviceName, p.direction, p.floor]} />
        <Section title="Classified events" empty="No events." rows={data.events}
          head={['Time', 'Event', 'Device']}
          render={(e) => [e.time, nice(e.type), e.deviceName]} />
        <Section title="Breaks" empty="No breaks." rows={data.breaks}
          head={['Start', 'End', 'Length']}
          render={(b) => [b.start, b.end || '-', fmtMinutes(b.minutes)]} />
        <Section title="Alerts" empty="No alerts." rows={data.alerts}
          head={['Type', 'Time', 'Message']}
          render={(a) => [nice(a.type), a.time || '-', a.message]} />
      </div>
    </div>
  )
}

function Item({ label, value }) {
  return (
    <div>
      <dt className="text-xs text-slate-500">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  )
}

function Section({ title, head, rows, render, empty }) {
  return (
    <div>
      <h2 className="mb-2 font-semibold text-slate-700">{title}</h2>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>{head.map((h) => <th key={h}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={head.length} className="py-4 text-center text-slate-500">{empty}</td></tr>
            )}
            {rows.map((row, i) => (
              <tr key={i}>
                {render(row).map((cell, j) => <td key={j}>{cell}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
