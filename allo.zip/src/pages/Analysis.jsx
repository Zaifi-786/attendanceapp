import { useState } from 'react'
import { listEmployees } from '../api/employees'
import { runAnalysis } from '../api/analysis'
import useFetch from '../hooks/useFetch'
import { ErrorBox, Field, Notice, PageHeader } from '../components/ui'
import { today } from '../utils/format'

// ANL-3 and ANL-5: run the analysis by hand. The result replaces what is stored for those days.
export default function Analysis() {
  const [employeeId, setEmployeeId] = useState('')
  const [fromDate, setFromDate] = useState(today())
  const [toDate, setToDate] = useState(today())
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState(null)

  const employees = useFetch(() => listEmployees({ status: 'Active', pageSize: 500 }), [])

  async function submit(e) {
    e.preventDefault()
    setError('')
    setResult(null)
    if (toDate < fromDate) {
      setError('The end date cannot be before the start date.')
      return
    }
    setBusy(true)
    try {
      const r = await runAnalysis({
        employeeId: employeeId ? Number(employeeId) : null,
        fromDate,
        toDate,
      })
      setResult(r)
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="max-w-xl">
      <PageHeader title="Run analysis" subtitle="The analysis also runs by itself every night for the previous day" />

      <form onSubmit={submit} className="card space-y-4">
        <ErrorBox message={error} />
        {result && (
          <Notice kind="success">
            Done. {result.daysAnalyzed} days analysed, {result.daysSkippedNoShift} skipped because there was no shift.
          </Notice>
        )}

        <Field label="Employee" hint="Leave on 'All employees' to run for everyone.">
          <select className="input" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
            <option value="">All employees</option>
            {(employees.data?.items || []).map((e) => (
              <option key={e.id} value={e.id}>{e.employeeCode} - {e.name}</option>
            ))}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="From">
            <input type="date" className="input" value={fromDate} onChange={(e) => setFromDate(e.target.value)} required />
          </Field>
          <Field label="To">
            <input type="date" className="input" value={toDate} onChange={(e) => setToDate(e.target.value)} required />
          </Field>
        </div>
        <p className="text-sm text-slate-500">
          Running it again for the same days gives the same result. The new result replaces the old one and uses the current settings.
        </p>
        <button className="btn btn-primary" disabled={busy}>{busy ? 'Running...' : 'Run analysis'}</button>
      </form>
    </div>
  )
}
