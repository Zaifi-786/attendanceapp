import { useState } from 'react'
import { Link } from 'react-router-dom'
import { getUnmappedPunches, getUnscheduledPunches } from '../api/reports'
import useFetch from '../hooks/useFetch'
import { EmptyRow, ErrorBox, Loading, PageHeader } from '../components/ui'
import { fmtDate, fmtTime, toISODate } from '../utils/format'

// RPT-6 and DEV-8: punches that need an admin to look at them
export default function Punches() {
  const now = new Date()
  const weekAgo = new Date()
  weekAgo.setDate(now.getDate() - 7)

  const [tab, setTab] = useState('unmapped')
  const [from, setFrom] = useState(toISODate(weekAgo))
  const [to, setTo] = useState(toISODate(now))

  const unmapped = useFetch(tab === 'unmapped' ? () => getUnmappedPunches(from, to) : null, [tab, from, to])
  const unscheduled = useFetch(tab === 'unscheduled' ? () => getUnscheduledPunches(from, to) : null, [tab, from, to])
  const current = tab === 'unmapped' ? unmapped : unscheduled

  const tabClass = (name) =>
    `border-b-2 px-3 py-2 text-sm font-medium ${tab === name ? 'border-blue-600 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`

  return (
    <div>
      <PageHeader title="Unmapped and unscheduled punches" subtitle="Punches that could not be matched to an employee or a shift">
        <input type="date" className="input w-auto" value={from} onChange={(e) => setFrom(e.target.value)} />
        <span className="text-sm text-slate-500">to</span>
        <input type="date" className="input w-auto" value={to} onChange={(e) => setTo(e.target.value)} />
      </PageHeader>

      <div className="mb-4 flex border-b border-slate-200">
        <button className={tabClass('unmapped')} onClick={() => setTab('unmapped')}>Unmapped (no employee)</button>
        <button className={tabClass('unscheduled')} onClick={() => setTab('unscheduled')}>Unscheduled (no shift)</button>
      </div>

      <ErrorBox message={current.error} onRetry={current.reload} />
      {current.loading && !current.data && <Loading />}

      {tab === 'unmapped' && unmapped.data && (
        <>
          <p className="mb-2 text-sm text-slate-500">
            To fix these, add the device user ID to the right employee on the <Link to="/employees" className="text-blue-600 underline">Employees</Link> page.
          </p>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr><th>Device user ID</th><th>Date</th><th>Time</th><th>Device</th><th>Direction</th><th>Floor</th></tr>
              </thead>
              <tbody>
                {unmapped.data.length === 0 && <EmptyRow cols={6} />}
                {unmapped.data.map((p) => (
                  <tr key={p.id}>
                    <td className="font-medium">{p.deviceUserId}</td>
                    <td>{fmtDate(p.time)}</td>
                    <td>{fmtTime(p.time)}</td>
                    <td>{p.deviceName}</td>
                    <td>{p.direction}</td>
                    <td>{p.floor}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'unscheduled' && unscheduled.data && (
        <>
          <p className="mb-2 text-sm text-slate-500">
            These employees punched on a day with no shift. Assign a shift on the <Link to="/shifts/assign" className="text-blue-600 underline">Assign shifts</Link> page, then run the analysis again.
          </p>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr><th>Code</th><th>Employee</th><th>Date</th><th>Time</th><th>Device</th><th>Direction</th></tr>
              </thead>
              <tbody>
                {unscheduled.data.length === 0 && <EmptyRow cols={6} />}
                {unscheduled.data.map((p) => (
                  <tr key={p.id}>
                    <td>{p.employeeCode}</td>
                    <td className="font-medium">{p.employeeName}</td>
                    <td>{fmtDate(p.date)}</td>
                    <td>{fmtTime(p.time)}</td>
                    <td>{p.deviceName}</td>
                    <td>{p.direction}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  )
}
