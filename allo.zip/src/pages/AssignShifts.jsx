import { useState } from 'react'
import { listDepartments } from '../api/departments'
import { listEmployees } from '../api/employees'
import { assignShift, bulkAssignShift, listAssignments, listShifts, removeAssignment } from '../api/shifts'
import useFetch from '../hooks/useFetch'
import { ErrorBox, Field, Notice, PageHeader } from '../components/ui'
import { fmtDate, today } from '../utils/format'

// SHF-2 (one employee) and SHF-3 (a department or a selection of employees)
export default function AssignShifts() {
  const [mode, setMode] = useState('one') // one | department | selected
  const [shiftId, setShiftId] = useState('')
  const [fromDate, setFromDate] = useState(today())
  const [toDate, setToDate] = useState('')
  const [employeeId, setEmployeeId] = useState('')
  const [departmentId, setDepartmentId] = useState('')
  const [picked, setPicked] = useState([])
  const [filter, setFilter] = useState('')

  const [error, setError] = useState('')
  const [result, setResult] = useState(null)
  const [busy, setBusy] = useState(false)

  const shifts = useFetch(() => listShifts(), [])
  const departments = useFetch(() => listDepartments(), [])
  const employees = useFetch(() => listEmployees({ status: 'Active', pageSize: 500 }), [])
  const assignments = useFetch(
    mode === 'one' && employeeId ? () => listAssignments(employeeId) : null,
    [mode, employeeId]
  )

  const allEmployees = employees.data?.items || []
  const visible = allEmployees.filter((e) =>
    (e.name + e.employeeCode).toLowerCase().includes(filter.toLowerCase())
  )

  function togglePicked(id) {
    setPicked(picked.includes(id) ? picked.filter((x) => x !== id) : [...picked, id])
  }

  async function submit(e) {
    e.preventDefault()
    setError('')
    setResult(null)
    if (toDate && toDate < fromDate) {
      setError('The end date cannot be before the start date.')
      return
    }
    const base = { shiftId: Number(shiftId), fromDate, toDate: toDate || null }
    setBusy(true)
    try {
      if (mode === 'one') {
        await assignShift({ ...base, employeeId: Number(employeeId) })
        setResult({ assigned: 1, skipped: [] })
        assignments.reload()
      } else if (mode === 'department') {
        setResult(await bulkAssignShift({ ...base, departmentId: Number(departmentId) }))
      } else {
        if (picked.length === 0) throw new Error('Select at least one employee.')
        setResult(await bulkAssignShift({ ...base, employeeIds: picked }))
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  async function remove(id) {
    if (!window.confirm('Remove this assignment?')) return
    try {
      await removeAssignment(id)
      assignments.reload()
    } catch (err) {
      setError(err.message)
    }
  }

  const modeButton = (name, label) => (
    <button
      type="button"
      onClick={() => { setMode(name); setResult(null); setError('') }}
      className={`btn ${mode === name ? 'btn-primary' : ''}`}
    >
      {label}
    </button>
  )

  return (
    <div>
      <PageHeader title="Assign shifts" subtitle="An employee can only have one shift on any date" />

      <div className="grid gap-6 lg:grid-cols-2">
        <form onSubmit={submit} className="card space-y-4">
          <div className="flex flex-wrap gap-2">
            {modeButton('one', 'One employee')}
            {modeButton('department', 'Whole department')}
            {modeButton('selected', 'Selected employees')}
          </div>

          <ErrorBox message={error} />
          {result && (
            <Notice kind={result.skipped.length ? 'warn' : 'success'}>
              {result.assigned} assigned.
              {result.skipped.length > 0 && (
                <>
                  {' '}{result.skipped.length} skipped:
                  <ul className="mt-1 list-disc pl-5">
                    {result.skipped.map((s) => (
                      <li key={s.employeeId}>{s.employeeName}: {s.reason}</li>
                    ))}
                  </ul>
                </>
              )}
            </Notice>
          )}

          <Field label="Shift">
            <select className="input" value={shiftId} onChange={(e) => setShiftId(e.target.value)} required>
              <option value="">Select...</option>
              {(shifts.data || []).map((s) => (
                <option key={s.id} value={s.id}>{s.name} ({s.startTime} - {s.endTime})</option>
              ))}
            </select>
          </Field>

          {mode === 'one' && (
            <Field label="Employee">
              <select className="input" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} required>
                <option value="">Select...</option>
                {allEmployees.map((e) => <option key={e.id} value={e.id}>{e.employeeCode} - {e.name}</option>)}
              </select>
            </Field>
          )}

          {mode === 'department' && (
            <Field label="Department">
              <select className="input" value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} required>
                <option value="">Select...</option>
                {(departments.data || []).filter((d) => d.isActive).map((d) => (
                  <option key={d.id} value={d.id}>{d.name} ({d.employeeCount})</option>
                ))}
              </select>
            </Field>
          )}

          {mode === 'selected' && (
            <div>
              <input className="input mb-2" placeholder="Search employees" value={filter} onChange={(e) => setFilter(e.target.value)} />
              <div className="max-h-56 overflow-y-auto rounded-md border border-slate-200 p-2 text-sm">
                {visible.map((e) => (
                  <label key={e.id} className="flex items-center gap-2 py-0.5">
                    <input type="checkbox" checked={picked.includes(e.id)} onChange={() => togglePicked(e.id)} />
                    {e.employeeCode} - {e.name}
                  </label>
                ))}
                {visible.length === 0 && <p className="text-slate-500">No employees found.</p>}
              </div>
              <p className="mt-1 text-xs text-slate-500">{picked.length} selected</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Field label="From">
              <input type="date" className="input" value={fromDate} onChange={(e) => setFromDate(e.target.value)} required />
            </Field>
            <Field label="To (optional)" hint="Leave empty for no end date">
              <input type="date" className="input" value={toDate} onChange={(e) => setToDate(e.target.value)} />
            </Field>
          </div>

          <button className="btn btn-primary" disabled={busy}>{busy ? 'Assigning...' : 'Assign shift'}</button>
        </form>

        {mode === 'one' && (
          <div>
            <h2 className="mb-2 font-semibold text-slate-700">Current assignments</h2>
            {!employeeId && <p className="text-sm text-slate-500">Pick an employee to see their shifts.</p>}
            {assignments.data && (
              <div className="table-wrap">
                <table className="table">
                  <thead><tr><th>Shift</th><th>From</th><th>To</th><th></th></tr></thead>
                  <tbody>
                    {assignments.data.length === 0 && (
                      <tr><td colSpan={4} className="py-4 text-center text-slate-500">No shifts assigned.</td></tr>
                    )}
                    {assignments.data.map((a) => (
                      <tr key={a.id}>
                        <td className="font-medium">{a.shiftName}</td>
                        <td>{fmtDate(a.fromDate)}</td>
                        <td>{a.toDate ? fmtDate(a.toDate) : 'Open'}</td>
                        <td className="text-right"><button className="btn" onClick={() => remove(a.id)}>Remove</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
