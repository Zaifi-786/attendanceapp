import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { listDepartments } from '../api/departments'
import { exportDaily, getDailyReport } from '../api/reports'
import useFetch from '../hooks/useFetch'
import { EmptyRow, ErrorBox, HoursBadge, Loading, PageHeader } from '../components/ui'
import { fmtMinutes, today } from '../utils/format'

// RPT-1: one row per employee for the chosen day
export default function DailyReport() {
  const navigate = useNavigate()
  const [date, setDate] = useState(today())
  const [departmentId, setDepartmentId] = useState('')
  const [exportError, setExportError] = useState('')

  const departments = useFetch(() => listDepartments(), [])
  const report = useFetch(() => getDailyReport(date, departmentId), [date, departmentId])

  async function doExport(format) {
    setExportError('')
    try {
      await exportDaily(date, departmentId, format)
    } catch (e) {
      setExportError(e.message)
    }
  }

  const rows = report.data || []

  return (
    <div>
      <PageHeader title="Daily report" subtitle="Click a row to see the full day">
        <input type="date" className="input w-auto" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
        <select className="input w-auto" value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
          <option value="">All departments</option>
          {(departments.data || []).map((d) => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>
        <button className="btn" onClick={() => doExport('xlsx')}>Excel</button>
        <button className="btn" onClick={() => doExport('pdf')}>PDF</button>
      </PageHeader>

      <ErrorBox message={report.error || exportError} onRetry={report.error ? report.reload : undefined} />
      {report.loading && !report.data && <Loading />}

      {report.data && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Employee</th>
                <th>Department</th>
                <th>Shift</th>
                <th>Check-in</th>
                <th>Check-out</th>
                <th>Break</th>
                <th>Presence</th>
                <th>Work</th>
                <th>Overtime</th>
                <th>Shortfall</th>
                <th>Hours</th>
                <th>Alerts</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && <EmptyRow cols={13} text="No scheduled employees on this date." />}
              {rows.map((r) => (
                <tr
                  key={r.employeeId}
                  className="cursor-pointer hover:bg-blue-50"
                  onClick={() => navigate(`/reports/daily/${r.employeeId}/${date}`)}
                >
                  <td>{r.employeeCode}</td>
                  <td className="font-medium">{r.employeeName}</td>
                  <td>{r.department}</td>
                  <td>{r.shiftName}</td>
                  <td>{r.checkIn || '-'}</td>
                  <td>{r.checkOut || '-'}</td>
                  <td>{fmtMinutes(r.breakMinutes)}</td>
                  <td>{fmtMinutes(r.presenceMinutes)}</td>
                  <td>{fmtMinutes(r.workMinutes)}</td>
                  <td>{fmtMinutes(r.overtimeMinutes)}</td>
                  <td>{fmtMinutes(r.shortfallMinutes)}</td>
                  <td><HoursBadge value={r.shiftHoursStatus} /></td>
                  <td>
                    {r.alertCount > 0 ? <span className="font-semibold text-red-600">{r.alertCount}</span> : <span className="text-slate-400">0</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {report.data && <p className="mt-2 text-xs text-slate-500">{rows.length} employees</p>}
    </div>
  )
}
