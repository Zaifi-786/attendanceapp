import { getDeviceStatus } from '../api/devices'
import useFetch from '../hooks/useFetch'
import { Badge, EmptyRow, ErrorBox, Loading, PageHeader } from '../components/ui'
import { fmtDateTime } from '../utils/format'

// DEV-10: device status page
export default function Devices() {
  const { data, loading, error, reload } = useFetch(() => getDeviceStatus(), [])

  return (
    <div>
      <PageHeader title="Devices" subtitle="Status of the K50 machines">
        <button className="btn" onClick={reload}>Refresh</button>
      </PageHeader>

      <ErrorBox message={error} onRetry={reload} />
      {loading && !data && <Loading />}

      {data && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th><th>IP</th><th>Direction</th><th>Floor</th><th>State</th>
                <th>Last successful sync</th><th>Last error</th><th>Punches today</th><th>Clock drift</th>
              </tr>
            </thead>
            <tbody>
              {data.length === 0 && <EmptyRow cols={9} text="No devices configured." />}
              {data.map((d) => (
                <tr key={d.id}>
                  <td className="font-medium">{d.name}</td>
                  <td>{d.ip}</td>
                  <td>{d.direction}</td>
                  <td>{d.floor}</td>
                  <td><Badge color={d.enabled ? 'green' : 'gray'}>{d.enabled ? 'Enabled' : 'Disabled'}</Badge></td>
                  <td>{fmtDateTime(d.lastSuccessfulSync)}</td>
                  <td className={d.lastError ? 'text-red-600' : 'text-slate-400'}>{d.lastError || '-'}</td>
                  <td>{d.punchesToday}</td>
                  <td className={Math.abs(d.clockDriftSeconds) > 60 ? 'font-semibold text-amber-600' : ''}>
                    {d.clockDriftSeconds}s
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="mt-3 text-sm text-slate-500">Devices are added in the device service settings (appsettings), not here.</p>
    </div>
  )
}
