import { useState } from 'react'
import { listDepartments } from '../api/departments'
import {
  createEmployee, deactivateEmployee, listEmployees, reactivateEmployee, updateEmployee,
} from '../api/employees'
import useFetch from '../hooks/useFetch'
import { Badge, EmptyRow, ErrorBox, Field, Loading, Modal, PageHeader } from '../components/ui'
import { fmtDate, today } from '../utils/format'

const PAGE_SIZE = 20

// EMP-1, EMP-2, EMP-3 and DEP-2
export default function Employees() {
  const [search, setSearch] = useState('')
  const [departmentId, setDepartmentId] = useState('')
  const [status, setStatus] = useState('Active')
  const [page, setPage] = useState(1)
  const [editing, setEditing] = useState(null) // null = closed, {} = new, {...} = existing
  const [actionError, setActionError] = useState('')

  const departments = useFetch(() => listDepartments(), [])
  const list = useFetch(
    () => listEmployees({ search, departmentId, status, page, pageSize: PAGE_SIZE }),
    [search, departmentId, status, page]
  )

  const items = list.data?.items || []
  const total = list.data?.total || 0
  const lastPage = Math.max(1, Math.ceil(total / PAGE_SIZE))

  async function toggleActive(emp) {
    setActionError('')
    try {
      if (emp.status === 'Active') {
        if (!window.confirm(`Deactivate ${emp.name}? Their history is kept.`)) return
        await deactivateEmployee(emp.id)
      } else {
        await reactivateEmployee(emp.id)
      }
      list.reload()
    } catch (e) {
      setActionError(e.message)
    }
  }

  // changing a filter should go back to page 1
  const onFilter = (setter) => (e) => {
    setter(e.target.value)
    setPage(1)
  }

  return (
    <div>
      <PageHeader title="Employees" subtitle={`${total} found`}>
        <button className="btn btn-primary" onClick={() => setEditing({})}>Add employee</button>
      </PageHeader>

      <div className="mb-4 flex flex-wrap gap-2">
        <input className="input w-64" placeholder="Search name, code or device ID" value={search} onChange={onFilter(setSearch)} />
        <select className="input w-auto" value={departmentId} onChange={onFilter(setDepartmentId)}>
          <option value="">All departments</option>
          {(departments.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
        <select className="input w-auto" value={status} onChange={onFilter(setStatus)}>
          <option value="">Any status</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>

      <ErrorBox message={list.error || actionError} onRetry={list.error ? list.reload : undefined} />
      {list.loading && !list.data && <Loading />}

      {list.data && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Code</th><th>Name</th><th>Department</th><th>Join date</th>
                <th>Device user ID</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 && <EmptyRow cols={7} text="No employees match these filters." />}
              {items.map((e) => (
                <tr key={e.id}>
                  <td>{e.employeeCode}</td>
                  <td className="font-medium">{e.name}</td>
                  <td>{e.departmentName}</td>
                  <td>{fmtDate(e.joinDate)}</td>
                  <td>{e.deviceUserId}</td>
                  <td><Badge color={e.status === 'Active' ? 'green' : 'gray'}>{e.status}</Badge></td>
                  <td className="space-x-2 text-right">
                    <button className="btn" onClick={() => setEditing(e)}>Edit</button>
                    <button className="btn" onClick={() => toggleActive(e)}>
                      {e.status === 'Active' ? 'Deactivate' : 'Reactivate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {total > PAGE_SIZE && (
        <div className="mt-3 flex items-center justify-end gap-2 text-sm">
          <button className="btn" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span>Page {page} of {lastPage}</span>
          <button className="btn" disabled={page >= lastPage} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}

      {editing && (
        <EmployeeForm
          employee={editing}
          departments={(departments.data || []).filter((d) => d.isActive || d.id === editing.departmentId)}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null)
            list.reload()
          }}
        />
      )}
    </div>
  )
}

function EmployeeForm({ employee, departments, onClose, onSaved }) {
  const isNew = !employee.id
  const [form, setForm] = useState({
    employeeCode: employee.employeeCode || '',
    name: employee.name || '',
    departmentId: employee.departmentId || '',
    joinDate: employee.joinDate ? employee.joinDate.slice(0, 10) : today(),
    deviceUserId: employee.deviceUserId || '',
  })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      const body = { ...form, departmentId: Number(form.departmentId) }
      if (isNew) await createEmployee(body)
      else await updateEmployee(employee.id, body)
      onSaved()
    } catch (err) {
      setError(err.message)
      setBusy(false)
    }
  }

  return (
    <Modal title={isNew ? 'Add employee' : 'Edit employee'} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <ErrorBox message={error} />
        <Field label="Employee code" hint="Must be unique">
          <input className="input" value={form.employeeCode} onChange={set('employeeCode')} required />
        </Field>
        <Field label="Name">
          <input className="input" value={form.name} onChange={set('name')} required />
        </Field>
        <Field label="Department">
          <select className="input" value={form.departmentId} onChange={set('departmentId')} required>
            <option value="">Select...</option>
            {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </Field>
        <Field label="Join date">
          <input type="date" className="input" value={form.joinDate} onChange={set('joinDate')} required />
        </Field>
        <Field label="Device user ID" hint="The ID this person has on the K50 machine. Must be unique.">
          <input className="input" value={form.deviceUserId} onChange={set('deviceUserId')} required />
        </Field>
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  )
}
