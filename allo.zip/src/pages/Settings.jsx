import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getSettings, saveSettings } from '../api/settings'
import useFetch from '../hooks/useFetch'
import { ErrorBox, Field, Loading, Notice, PageHeader } from '../components/ui'

// SET-1, SET-2, SET-3
export default function Settings() {
  const { data, loading, error, reload } = useFetch(() => getSettings(), [])
  const [grace, setGrace] = useState('')
  const [flexi, setFlexi] = useState(false)
  const [saveError, setSaveError] = useState('')
  const [saved, setSaved] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (data) {
      setGrace(String(data.gracePeriodMinutes))
      setFlexi(data.flexiTimeCover)
    }
  }, [data])

  async function submit(e) {
    e.preventDefault()
    setSaveError('')
    setSaved(false)
    setBusy(true)
    try {
      await saveSettings({ gracePeriodMinutes: Number(grace), flexiTimeCover: flexi })
      setSaved(true)
    } catch (err) {
      setSaveError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="max-w-xl">
      <PageHeader title="Settings" />
      <ErrorBox message={error} onRetry={reload} />
      {loading && !data && <Loading />}

      {data && (
        <form onSubmit={submit} className="card space-y-4">
          <ErrorBox message={saveError} />
          {saved && (
            <Notice kind="success">
              Saved. Days that are already calculated keep the old settings until you{' '}
              <Link to="/analysis" className="underline">run the analysis again</Link>.
            </Notice>
          )}

          <Field label="Grace period (minutes)" hint="Used for check-in, check-out and shortfall alerts.">
            <input type="number" min="0" max="120" className="input w-32" value={grace} onChange={(e) => setGrace(e.target.value)} required />
          </Field>

          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" className="mt-1" checked={flexi} onChange={(e) => setFlexi(e.target.checked)} />
            <span>
              <span className="font-medium text-slate-700">Flexi time cover</span>
              <span className="block text-xs text-slate-500">Turn on or off.</span>
            </span>
          </label>

          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save settings'}</button>
        </form>
      )}
    </div>
  )
}
