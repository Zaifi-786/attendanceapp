import { useState } from 'react'
import { getAuditLog } from '../api/auditLog'
import useFetch from '../hooks/useFetch'
import { EmptyRow, ErrorBox, Loading, PageHeader } from '../components/ui'
import { fmtDateTime } from '../utils/format'

const PAGE_SIZE = 25

// AUTH-5: who changed employees, shifts or settings, and when
export default function AuditLog() {
  const [entity, setEntity] = useState('')
  const [page, setPage] = useState(1)
  const { data, loading, error, reload } = useFetch(
    () => getAuditLog({ entity, page, pageSize: PAGE_SIZE }),
    [entity, page]
  )

  const total = data?.total || 0
  const lastPage = Math.max(1, Math.ceil(total / PAGE_SIZE))

  return (
    <div>
      <PageHeader title="Audit log">
        <select className="input w-auto" value={entity} onChange={(e) => { setEntity(e.target.value); setPage(1) }}>
          <option value="">Everything</option>
          <option value="Employee">Employees</option>
          <option value="Shift">Shifts</option>
          <option value="Settings">Settings</option>
        </select>
      </PageHeader>

      <ErrorBox message={error} onRetry={reload} />
      {loading && !data && <Loading />}

      {data && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>When</th><th>User</th><th>Area</th><th>Action</th><th>Details</th></tr>
            </thead>
            <tbody>
              {data.items.length === 0 && <EmptyRow cols={5} />}
              {data.items.map((a) => (
                <tr key={a.id}>
                  <td>{fmtDateTime(a.when)}</td>
                  <td>{a.userName}</td>
                  <td>{a.entity}</td>
                  <td>{a.action}</td>
                  <td className="whitespace-normal">{a.summary}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {total > PAGE_SIZE && (
        <div className="mt-3 flex items-center justify-end gap-2 text-sm">
          <button className="btn" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span>Page {page} of {lastPage}</span>
          <button className="btn" disabled={page >= lastPage} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}
    </div>
  )
}
