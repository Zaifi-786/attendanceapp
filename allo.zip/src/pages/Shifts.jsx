import { useState } from 'react'
import { createShift, listShifts, updateShift } from '../api/shifts'
import useFetch from '../hooks/useFetch'
import { Badge, EmptyRow, ErrorBox, Field, Loading, Modal, PageHeader } from '../components/ui'
import { DAY_NAMES, fmtMinutes, today } from '../utils/format'

// SHF-1 and SHF-4
export default function Shifts() {
  const { data, loading, error, reload } = useFetch(() => listShifts(), [])
  const [editing, setEditing] = useState(null)

  return (
    <div>
      <PageHeader title="Shifts" subtitle="An end time earlier than the start time makes it an overnight shift">
        <button className="btn btn-primary" onClick={() => setEditing({})}>Add shift</button>
      </PageHeader>

      <ErrorBox message={error} onRetry={reload} />
      {loading && !data && <Loading />}

      {data && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr><th>Name</th><th>Start</th><th>End</th><th>Official break</th><th>Working days</th><th></th></tr>
            </thead>
            <tbody>
              {data.length === 0 && <EmptyRow cols={6} text="No shifts yet." />}
              {data.map((s) => (
                <tr key={s.id}>
                  <td className="font-medium">
                    {s.name} {s.isOvernight && <Badge color="blue">Overnight</Badge>}
                  </td>
                  <td>{s.startTime}</td>
                  <td>{s.endTime}</td>
                  <td>{fmtMinutes(s.breakMinutes)}</td>
                  <td>{s.workingDays.map((d) => DAY_NAMES[d - 1]).join(', ')}</td>
                  <td className="text-right"><button className="btn" onClick={() => setEditing(s)}>Edit</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <ShiftForm
          shift={editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null)
            reload()
          }}
        />
      )}
    </div>
  )
}

function ShiftForm({ shift, onClose, onSaved }) {
  const isNew = !shift.id
  const [form, setForm] = useState({
    name: shift.name || '',
    startTime: shift.startTime || '09:00',
    endTime: shift.endTime || '17:00',
    breakMinutes: shift.breakMinutes ?? 60,
    workingDays: shift.workingDays || [1, 2, 3, 4, 5],
    effectiveFrom: today(),
  })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value })
  const overnight = form.endTime < form.startTime

  function toggleDay(day) {
    const days = form.workingDays.includes(day)
      ? form.workingDays.filter((d) => d !== day)
      : [...form.workingDays, day].sort()
    setForm({ ...form, workingDays: days })
  }

  async function submit(e) {
    e.preventDefault()
    if (form.workingDays.length === 0) {
      setError('Choose at least one working day.')
      return
    }
    setError('')
    setBusy(true)
    try {
      const body = {
        name: form.name,
        startTime: form.startTime,
        endTime: form.endTime,
        breakMinutes: Number(form.breakMinutes),
        workingDays: form.workingDays,
      }
      if (isNew) await createShift(body)
      else await updateShift(shift.id, { ...body, effectiveFrom: form.effectiveFrom })
      onSaved()
    } catch (err) {
      setError(err.message)
      setBusy(false)
    }
  }

  return (
    <Modal title={isNew ? 'Add shift' : 'Edit shift'} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <ErrorBox message={error} />
        <Field label="Name">
          <input className="input" value={form.name} onChange={set('name')} required />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Start time">
            <input type="time" className="input" value={form.startTime} onChange={set('startTime')} required />
          </Field>
          <Field label="End time">
            <input type="time" className="input" value={form.endTime} onChange={set('endTime')} required />
          </Field>
        </div>
        {overnight && <p className="text-sm text-blue-700">This is an overnight shift. It belongs to the date it starts.</p>}
        <Field label="Official break (minutes)">
          <input type="number" min="0" max="480" className="input" value={form.breakMinutes} onChange={set('breakMinutes')} required />
        </Field>
        <div>
          <span className="mb-1 block text-sm font-medium text-slate-700">Working days</span>
          <div className="flex flex-wrap gap-2">
            {DAY_NAMES.map((name, i) => (
              <label key={name} className="flex items-center gap-1 text-sm">
                <input type="checkbox" checked={form.workingDays.includes(i + 1)} onChange={() => toggleDay(i + 1)} />
                {name}
              </label>
            ))}
          </div>
        </div>
        {!isNew && (
          <Field label="Apply changes from" hint="Days before this date keep their old results.">
            <input type="date" className="input" value={form.effectiveFrom} onChange={set('effectiveFrom')} required />
          </Field>
        )}
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  )
}
