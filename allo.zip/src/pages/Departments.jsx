import { useState } from 'react'
import {
  activateDepartment, createDepartment, deactivateDepartment, listDepartments, renameDepartment,
} from '../api/departments'
import useFetch from '../hooks/useFetch'
import { Badge, EmptyRow, ErrorBox, Loading, PageHeader } from '../components/ui'

// DEP-1: create, rename, deactivate
export default function Departments() {
  const { data, loading, error, reload } = useFetch(() => listDepartments(), [])
  const [newName, setNewName] = useState('')
  const [editId, setEditId] = useState(null)
  const [editName, setEditName] = useState('')
  const [actionError, setActionError] = useState('')

  // runs an API call, shows the error if it fails and reloads the list when it works
  async function run(fn) {
    setActionError('')
    try {
      await fn()
      reload()
    } catch (e) {
      setActionError(e.message)
    }
  }

  async function add(e) {
    e.preventDefault()
    if (!newName.trim()) return
    await run(async () => {
      await createDepartment(newName.trim())
      setNewName('')
    })
  }

  async function saveRename(id) {
    if (!editName.trim()) return
    await run(async () => {
      await renameDepartment(id, editName.trim())
      setEditId(null)
    })
  }

  return (
    <div>
      <PageHeader title="Departments" />

      <form onSubmit={add} className="mb-4 flex gap-2">
        <input className="input max-w-xs" placeholder="New department name" value={newName} onChange={(e) => setNewName(e.target.value)} />
        <button className="btn btn-primary">Add</button>
      </form>

      <ErrorBox message={error || actionError} onRetry={error ? reload : undefined} />
      {loading && !data && <Loading />}

      {data && (
        <div className="table-wrap max-w-3xl">
          <table className="table">
            <thead>
              <tr><th>Name</th><th>Active employees</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {data.length === 0 && <EmptyRow cols={4} text="No departments yet." />}
              {data.map((d) => (
                <tr key={d.id}>
                  <td className="font-medium">
                    {editId === d.id ? (
                      <input className="input" value={editName} autoFocus onChange={(e) => setEditName(e.target.value)} />
                    ) : (
                      d.name
                    )}
                  </td>
                  <td>{d.employeeCount}</td>
                  <td><Badge color={d.isActive ? 'green' : 'gray'}>{d.isActive ? 'Active' : 'Inactive'}</Badge></td>
                  <td className="space-x-2 text-right">
                    {editId === d.id ? (
                      <>
                        <button className="btn btn-primary" onClick={() => saveRename(d.id)}>Save</button>
                        <button className="btn" onClick={() => setEditId(null)}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <button className="btn" onClick={() => { setEditId(d.id); setEditName(d.name) }}>Rename</button>
                        <button
                          className="btn"
                          onClick={() => run(() => (d.isActive ? deactivateDepartment(d.id) : activateDepartment(d.id)))}
                        >
                          {d.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="mt-3 text-sm text-slate-500">To move an employee to another department, edit the employee.</p>
    </div>
  )
}
