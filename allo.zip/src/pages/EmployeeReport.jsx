import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { listEmployees } from '../api/employees'
import { exportEmployeePeriod, getEmployeePeriod } from '../api/reports'
import useFetch from '../hooks/useFetch'
import { EmptyRow, ErrorBox, HoursBadge, Loading, PageHeader, StatusBadge } from '../components/ui'
import { fmtDate, fmtMinutes, monthRange } from '../utils/format'

// RPT-3: one row per day for one employee, with totals at the bottom
export default function EmployeeReport() {
  const navigate = useNavigate()
  const range = monthRange()
  const [employeeId, setEmployeeId] = useState('')
  const [from, setFrom] = useState(range.from)
  const [to, setTo] = useState(range.to)
  const [exportError, setExportError] = useState('')

  const employees = useFetch(() => listEmployees({ pageSize: 500 }), [])
  const ready = employeeId && from && to && from <= to
  const report = useFetch(ready ? () => getEmployeePeriod(employeeId, from, to) : null, [employeeId, from, to])

  async function doExport(format) {
    setExportError('')
    try {
      await exportEmployeePeriod(employeeId, from, to, format)
    } catch (e) {
      setExportError(e.message)
    }
  }

  const data = ready ? report.data : null
  const t = data && data.totals

  return (
    <div>
      <PageHeader title="Employee report" subtitle="Pick an employee and a date range">
        <select className="input w-auto" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
          <option value="">Select employee...</option>
          {(employees.data?.items || []).map((e) => (
            <option key={e.id} value={e.id}>{e.employeeCode} - {e.name}</option>
          ))}
        </select>
        <input type="date" className="input w-auto" value={from} onChange={(e) => setFrom(e.target.value)} />
        <span className="text-sm text-slate-500">to</span>
        <input type="date" className="input w-auto" value={to} onChange={(e) => setTo(e.target.value)} />
        <button className="btn" disabled={!ready} onClick={() => doExport('xlsx')}>Excel</button>
        <button className="btn" disabled={!ready} onClick={() => doExport('pdf')}>PDF</button>
      </PageHeader>

      {from > to && <ErrorBox message="The start date must be before the end date." />}
      <ErrorBox message={report.error || exportError} onRetry={report.error ? report.reload : undefined} />
      {!employeeId && <p className="text-sm text-slate-500">Choose an employee to see the report.</p>}
      {ready && report.loading && !data && <Loading />}

      {data && (
        <>
          <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-8">
            <Total label="Days worked" value={t.daysWorked} />
            <Total label="Work time" value={fmtMinutes(t.workMinutes)} />
            <Total label="Overtime" value={fmtMinutes(t.overtimeMinutes)} />
            <Total label="Shortfall" value={fmtMinutes(t.shortfallMinutes)} />
            <Total label="Break time" value={fmtMinutes(t.breakMinutes)} />
            <Total label="Late arrivals" value={t.lateArrivals} />
            <Total label="Early exits" value={t.earlyExits} />
            <Total label="Missing punches" value={t.missingPunches} />
          </div>

          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Date</th><th>Status</th><th>Shift</th><th>Check-in</th><th>Check-out</th>
                  <th>Break</th><th>Work</th><th>Overtime</th><th>Shortfall</th><th>Hours</th><th>Alerts</th>
                </tr>
              </thead>
              <tbody>
                {data.days.length === 0 && <EmptyRow cols={11} text="No scheduled days in this range." />}
                {data.days.map((d) => (
                  <tr
                    key={d.date}
                    className="cursor-pointer hover:bg-blue-50"
                    onClick={() => navigate(`/reports/daily/${employeeId}/${d.date}`)}
                  >
                    <td>{fmtDate(d.date)}</td>
                    <td><StatusBadge status={d.status} /></td>
                    <td>{d.shiftName}</td>
                    <td>{d.checkIn || '-'}</td>
                    <td>{d.checkOut || '-'}</td>
                    <td>{fmtMinutes(d.breakMinutes)}</td>
                    <td>{fmtMinutes(d.workMinutes)}</td>
                    <td>{fmtMinutes(d.overtimeMinutes)}</td>
                    <td>{fmtMinutes(d.shortfallMinutes)}</td>
                    <td><HoursBadge value={d.shiftHoursStatus} /></td>
                    <td>{d.alertCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  )
}

function Total({ label, value }) {
  return (
    <div className="card p-3">
      <div className="text-xs text-slate-500">{label}</div>
      <div className="mt-0.5 text-lg font-semibold">{value}</div>
    </div>
  )
}
