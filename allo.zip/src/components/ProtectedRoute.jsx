import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

// AUTH-3: every page sits behind this guard
export default function ProtectedRoute() {
  const { user, checking } = useAuth()
  const location = useLocation()

  if (checking) {
    return <div className="p-10 text-center text-slate-500">Loading...</div>
  }
  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />
  }
  return <Outlet />
}
