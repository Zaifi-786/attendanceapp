import { useState } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const sections = [
  {
    title: 'Overview',
    links: [{ to: '/', label: 'Dashboard', end: true }],
  },
  {
    title: 'Reports',
    links: [
      { to: '/reports/daily', label: 'Daily report' },
      { to: '/reports/employee', label: 'Employee report' },
      { to: '/punches', label: 'Unmapped / unscheduled' },
    ],
  },
  {
    title: 'Master data',
    links: [
      { to: '/employees', label: 'Employees' },
      { to: '/departments', label: 'Departments' },
      { to: '/shifts', label: 'Shifts' },
      { to: '/shifts/assign', label: 'Assign shifts' },
    ],
  },
  {
    title: 'System',
    links: [
      { to: '/settings', label: 'Settings' },
      { to: '/analysis', label: 'Run analysis' },
      { to: '/devices', label: 'Devices' },
      { to: '/audit-log', label: 'Audit log' },
    ],
  },
]

export default function Layout() {
  const { user, logout } = useAuth()
  const [open, setOpen] = useState(false)

  return (
    <div className="min-h-screen md:flex">
      {/* sidebar */}
      <aside
        className={`${open ? 'block' : 'hidden'} w-full shrink-0 bg-slate-900 text-slate-200 md:block md:w-56`}
      >
        <div className="px-4 py-4 text-lg font-semibold text-white">Attendance</div>
        <nav className="px-2 pb-4">
          {sections.map((s) => (
            <div key={s.title} className="mb-3">
              <div className="px-2 pb-1 text-xs uppercase tracking-wide text-slate-500">{s.title}</div>
              {s.links.map((l) => (
                <NavLink
                  key={l.to}
                  to={l.to}
                  end={l.end}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `block rounded px-2 py-1.5 text-sm ${
                      isActive ? 'bg-blue-600 text-white' : 'hover:bg-slate-800'
                    }`
                  }
                >
                  {l.label}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-2">
          <button className="btn md:hidden" onClick={() => setOpen(!open)}>
            Menu
          </button>
          <div className="hidden md:block" />
          <div className="flex items-center gap-3 text-sm">
            <span className="text-slate-600">{user.displayName || user.userName}</span>
            <button className="btn" onClick={logout}>
              Sign out
            </button>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
