import { useEffect } from 'react'

export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold text-slate-800">{title}</h1>
        {subtitle && <p className="mt-0.5 text-sm text-slate-500">{subtitle}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  )
}

export function Loading({ text = 'Loading...' }) {
  return <div className="py-10 text-center text-sm text-slate-500">{text}</div>
}

export function ErrorBox({ message, onRetry }) {
  if (!message) return null
  return (
    <div className="mb-4 flex items-center justify-between gap-3 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
      <span>{message}</span>
      {onRetry && (
        <button className="btn" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  )
}

export function Notice({ children, kind = 'info' }) {
  const colors = {
    info: 'border-blue-200 bg-blue-50 text-blue-800',
    success: 'border-green-200 bg-green-50 text-green-800',
    warn: 'border-amber-200 bg-amber-50 text-amber-800',
  }
  return <div className={`mb-4 rounded-md border px-3 py-2 text-sm ${colors[kind]}`}>{children}</div>
}

const badgeColors = {
  green: 'bg-green-100 text-green-700',
  red: 'bg-red-100 text-red-700',
  amber: 'bg-amber-100 text-amber-800',
  blue: 'bg-blue-100 text-blue-700',
  gray: 'bg-slate-100 text-slate-600',
}

export function Badge({ color = 'gray', children }) {
  return (
    <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium ${badgeColors[color]}`}>
      {children}
    </span>
  )
}

// colour for the status column in the reports
export function StatusBadge({ status }) {
  const map = {
    Present: ['green', 'Present'],
    Late: ['amber', 'Late'],
    EarlyExit: ['amber', 'Early exit'],
    MissingCheckOut: ['red', 'Missing check-out'],
    Absent: ['red', 'Absent'],
  }
  const [color, label] = map[status] || ['gray', status || '-']
  return <Badge color={color}>{label}</Badge>
}

export function HoursBadge({ value }) {
  const map = { Met: 'green', Short: 'red', Over: 'blue' }
  if (!value || value === 'None') return <span className="text-slate-400">-</span>
  return <Badge color={map[value] || 'gray'}>{value}</Badge>
}

export function Field({ label, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-slate-700">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
    </label>
  )
}

export function Modal({ title, onClose, children, wide }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div className="fixed inset-0 z-40 flex items-start justify-center overflow-y-auto bg-slate-900/40 p-4">
      <div className={`mt-10 w-full rounded-lg bg-white shadow-xl ${wide ? 'max-w-2xl' : 'max-w-md'}`}>
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
          <h2 className="font-semibold text-slate-800">{title}</h2>
          <button onClick={onClose} className="text-xl leading-none text-slate-400 hover:text-slate-700" aria-label="Close">
            &times;
          </button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  )
}

export function Stat({ label, value, color = 'text-slate-800' }) {
  return (
    <div className="card">
      <div className="text-sm text-slate-500">{label}</div>
      <div className={`mt-1 text-3xl font-semibold ${color}`}>{value}</div>
    </div>
  )
}

export function EmptyRow({ cols, text = 'Nothing to show.' }) {
  return (
    <tr>
      <td colSpan={cols} className="py-8 text-center text-slate-500">
        {text}
      </td>
    </tr>
  )
}
