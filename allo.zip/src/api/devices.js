import { http } from './http'

// DEV-10: GET /api/devices/status
//   -> [{ id, name, ip, direction, floor, enabled, lastSuccessfulSync, lastError,
//         punchesToday, clockDriftSeconds }]
export const getDeviceStatus = () => http.get('/devices/status')
