import { http } from './http'

// DEP-1
// GET  /api/departments                 -> [{ id, name, isActive, employeeCount }]
// POST /api/departments                 body: { name }
// PUT  /api/departments/{id}            body: { name }   (rename)
// POST /api/departments/{id}/deactivate
// POST /api/departments/{id}/activate
export const listDepartments = () => http.get('/departments')
export const createDepartment = (name) => http.post('/departments', { name })
export const renameDepartment = (id, name) => http.put(`/departments/${id}`, { name })
export const deactivateDepartment = (id) => http.post(`/departments/${id}/deactivate`)
export const activateDepartment = (id) => http.post(`/departments/${id}/activate`)
