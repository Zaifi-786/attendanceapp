import { http } from './http'

// SHF-1
// GET  /api/shifts  -> [{ id, name, startTime, endTime, breakMinutes, workingDays: [1..7], isOvernight }]
//   times are "HH:mm", working days use 1 = Monday ... 7 = Sunday
//   isOvernight is worked out by the server (end time earlier than start time)
// POST /api/shifts  body: { name, startTime, endTime, breakMinutes, workingDays }
export const listShifts = () => http.get('/shifts')
export const createShift = (data) => http.post('/shifts', data)

// SHF-4: PUT /api/shifts/{id}
//   body: { name, startTime, endTime, breakMinutes, workingDays, effectiveFrom }
//   The change only applies from effectiveFrom so past results stay the same.
export const updateShift = (id, data) => http.put(`/shifts/${id}`, data)

// SHF-2: GET /api/shift-assignments?employeeId=
//   -> [{ id, employeeId, shiftId, shiftName, fromDate, toDate }]
export const listAssignments = (employeeId) => http.get('/shift-assignments', { employeeId })

// SHF-2: POST /api/shift-assignments
//   body: { employeeId, shiftId, fromDate, toDate }   (toDate can be null)
//   The API answers 400/409 if the employee already has a shift on any of those dates.
export const assignShift = (data) => http.post('/shift-assignments', data)

// SHF-3: POST /api/shift-assignments/bulk
//   body: { shiftId, fromDate, toDate, departmentId }  or  { shiftId, fromDate, toDate, employeeIds: [] }
//   -> { assigned, skipped: [{ employeeId, employeeName, reason }] }
export const bulkAssignShift = (data) => http.post('/shift-assignments/bulk', data)

// DELETE /api/shift-assignments/{id}
export const removeAssignment = (id) => http.del(`/shift-assignments/${id}`)
