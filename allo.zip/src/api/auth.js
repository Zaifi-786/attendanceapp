import { http } from './http'

// AUTH-1, AUTH-2: only Admin users get a token back from the API.
// POST /api/auth/login   body: { userName, password }
//   -> { token, expiresAt, user: { id, userName, displayName, roles: ['Admin'] } }
export const login = (userName, password) => http.post('/auth/login', { userName, password })

// GET /api/auth/me  -> same user object as above. Used to check a saved token on page refresh.
export const getMe = () => http.get('/auth/me')
