import { mockRequest } from './mock'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'
const USE_MOCK = import.meta.env.VITE_USE_MOCK === 'true'
const TOKEN_KEY = 'ams_token'

// The token lives in sessionStorage so it is gone when the tab closes.
export const tokenStore = {
  get: () => sessionStorage.getItem(TOKEN_KEY),
  set: (t) => sessionStorage.setItem(TOKEN_KEY, t),
  clear: () => sessionStorage.removeItem(TOKEN_KEY),
}

// AuthContext sets this so a 401 anywhere sends the user back to sign-in
let onUnauthorized = () => {}
export function setUnauthorizedHandler(fn) {
  onUnauthorized = fn
}

export class ApiError extends Error {
  constructor(message, status, details) {
    super(message)
    this.status = status
    this.details = details
  }
}

function buildUrl(path, params) {
  const query = new URLSearchParams()
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') query.append(key, value)
  })
  const qs = query.toString()
  return BASE_URL + path + (qs ? '?' + qs : '')
}

// Turns the .NET ProblemDetails / validation response into one readable message
async function readError(res) {
  let body = null
  try {
    body = await res.json()
  } catch {
    // response had no json body
  }
  if (body && body.errors) {
    const all = Object.values(body.errors).flat()
    if (all.length) return new ApiError(all.join(' '), res.status, body)
  }
  const text = (body && (body.detail || body.title || body.message)) || `Request failed (${res.status})`
  return new ApiError(text, res.status, body)
}

async function request(method, path, { params, body } = {}) {
  if (USE_MOCK) {
    return mockRequest(method, path, params, body)
  }

  const headers = { Accept: 'application/json' }
  const token = tokenStore.get()
  if (token) headers.Authorization = 'Bearer ' + token
  if (body !== undefined) headers['Content-Type'] = 'application/json'

  let res
  try {
    res = await fetch(buildUrl(path, params), {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      cache: 'no-store',
    })
  } catch {
    throw new ApiError('Cannot reach the server. Check your connection and try again.', 0)
  }

  // A 401 on the login call just means wrong password, so don't treat it as an expired session
  if (res.status === 401 && path !== '/auth/login') {
    tokenStore.clear()
    onUnauthorized()
    throw new ApiError('Your session has expired. Please sign in again.', 401)
  }
  if (!res.ok) throw await readError(res)
  if (res.status === 204) return null
  return res.json()
}

export const http = {
  get: (path, params) => request('GET', path, { params }),
  post: (path, body) => request('POST', path, { body: body === undefined ? {} : body }),
  put: (path, body) => request('PUT', path, { body }),
  del: (path) => request('DELETE', path),
}

// Used for the Excel / PDF export buttons
export async function downloadFile(path, params, fallbackName) {
  if (USE_MOCK) {
    throw new ApiError('Export is not available in demo mode.', 0)
  }
  const headers = {}
  const token = tokenStore.get()
  if (token) headers.Authorization = 'Bearer ' + token

  const res = await fetch(buildUrl(path, params), { headers, cache: 'no-store' })
  if (res.status === 401) {
    tokenStore.clear()
    onUnauthorized()
    throw new ApiError('Your session has expired. Please sign in again.', 401)
  }
  if (!res.ok) throw await readError(res)

  // use the file name the server sends, if there is one
  let name = fallbackName
  const disposition = res.headers.get('Content-Disposition') || ''
  const match = disposition.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i)
  if (match) name = decodeURIComponent(match[1])

  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}
