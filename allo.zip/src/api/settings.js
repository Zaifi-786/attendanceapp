import { http } from './http'

// SET-1, SET-2
// GET /api/settings -> { gracePeriodMinutes, flexiTimeCover }
// PUT /api/settings body: same shape. Past days are NOT touched by this (SET-3).
export const getSettings = () => http.get('/settings')
export const saveSettings = (data) => http.put('/settings', data)
