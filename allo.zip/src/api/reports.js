import { http, downloadFile } from './http'

// RPT-1: GET /api/reports/daily?date=yyyy-MM-dd&departmentId=
//   -> [DailyRow]
//   DailyRow: { employeeId, employeeCode, employeeName, department, shiftName,
//               checkIn, checkOut, breakMinutes, presenceMinutes, workMinutes,
//               overtimeMinutes, shortfallMinutes, shiftHoursStatus, alertCount, status }
export const getDailyReport = (date, departmentId) =>
  http.get('/reports/daily', { date, departmentId })

// RPT-2: GET /api/reports/daily/{employeeId}/{date}
//   -> { employee, date, shift, settingsUsed, rawPunches, events, breaks, alerts, summary }
export const getDayDetail = (employeeId, date) =>
  http.get(`/reports/daily/${employeeId}/${date}`)

// RPT-3: GET /api/reports/employee-period?employeeId=&from=&to=
//   -> { employee, from, to, days: [DailyRow + date], totals: { daysWorked, workMinutes,
//        overtimeMinutes, shortfallMinutes, breakMinutes, lateArrivals, earlyExits, missingPunches } }
//   The totals come from the server so they match the stored results (RPT-7).
export const getEmployeePeriod = (employeeId, from, to) =>
  http.get('/reports/employee-period', { employeeId, from, to })

// RPT-4: GET /api/reports/dashboard?date=yyyy-MM-dd
//   -> { date,
//        totals: { present, absent, late, earlyExit, missingCheckOut },
//        byDepartment: [{ department, present, absent, late, earlyExit, missingCheckOut }],
//        trend: [{ date, present, absent, late }],        (30 days)
//        openAlertsByType: [{ type, count }] }
export const getDashboard = (date) => http.get('/reports/dashboard', { date })

// RPT-5: exports. The API returns the file itself.
// GET /api/reports/daily/export?date=&departmentId=&format=xlsx|pdf
// GET /api/reports/employee-period/export?employeeId=&from=&to=&format=xlsx|pdf
export const exportDaily = (date, departmentId, format) =>
  downloadFile('/reports/daily/export', { date, departmentId, format }, `daily-${date}.${format}`)

export const exportEmployeePeriod = (employeeId, from, to, format) =>
  downloadFile(
    '/reports/employee-period/export',
    { employeeId, from, to, format },
    `employee-${employeeId}-${from}-${to}.${format}`
  )

// RPT-6 and DEV-8, ANL-7
// GET /api/punches/unmapped?from=&to=      punches whose device user ID matches no employee
//   -> [{ id, deviceName, deviceUserId, time, direction, floor }]
// GET /api/punches/unscheduled?from=&to=   punches of employees that have no shift that day
//   -> [{ id, employeeId, employeeCode, employeeName, date, time, deviceName, direction }]
export const getUnmappedPunches = (from, to) => http.get('/punches/unmapped', { from, to })
export const getUnscheduledPunches = (from, to) => http.get('/punches/unscheduled', { from, to })
