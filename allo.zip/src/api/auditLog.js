import { http } from './http'

// AUTH-5: GET /api/audit-log?from=&to=&entity=&page=&pageSize=
//   entity is 'Employee', 'Shift' or 'Settings' (empty = all)
//   -> { items: [{ id, when, userName, entity, entityId, action, summary }], total }
export const getAuditLog = (params) => http.get('/audit-log', params)
