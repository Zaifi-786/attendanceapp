// Fake data so the screens can be tried before the .NET API is ready.
// Turn it on with VITE_USE_MOCK=true. Nothing in here is used in production.

const wait = (ms) => new Promise((r) => setTimeout(r, ms))

let nextId = 100
const departments = [
  { id: 1, name: 'Production', isActive: true },
  { id: 2, name: 'Warehouse', isActive: true },
  { id: 3, name: 'Administration', isActive: true },
  { id: 4, name: 'Security', isActive: true },
]

const names = [
  'Ahmed Raza', 'Bilal Khan', 'Chaudhry Imran', 'Danish Ali', 'Farhan Shah', 'Gul Nawaz',
  'Hina Malik', 'Irfan Baig', 'Junaid Iqbal', 'Kamran Butt', 'Laiba Noor', 'Mubashir Hassan',
  'Nadia Aslam', 'Owais Qureshi', 'Qasim Javed', 'Rabia Sheikh',
]
const employees = names.map((name, i) => ({
  id: i + 1,
  employeeCode: 'E' + String(1001 + i),
  name,
  departmentId: (i % 4) + 1,
  joinDate: '2023-0' + ((i % 9) + 1) + '-15',
  isActive: i !== 13,
  deviceUserId: String(200 + i),
}))

const shifts = [
  { id: 1, name: 'Day shift', startTime: '09:00', endTime: '17:00', breakMinutes: 60, workingDays: [1, 2, 3, 4, 5], isOvernight: false },
  { id: 2, name: 'Early shift', startTime: '06:00', endTime: '14:00', breakMinutes: 30, workingDays: [1, 2, 3, 4, 5, 6], isOvernight: false },
  { id: 3, name: 'Night shift', startTime: '21:00', endTime: '05:00', breakMinutes: 45, workingDays: [1, 2, 3, 4, 5], isOvernight: true },
]

let assignments = employees.map((e, i) => ({
  id: i + 1,
  employeeId: e.id,
  shiftId: e.departmentId === 4 ? 3 : e.departmentId === 2 ? 2 : 1,
  fromDate: '2024-01-01',
  toDate: null,
}))

let settings = { gracePeriodMinutes: 10, flexiTimeCover: false }

const auditLog = [
  { id: 1, when: '2026-11-12T10:21:00', userName: 'admin', entity: 'Settings', entityId: '1', action: 'Updated', summary: 'Grace period changed from 5 to 10 minutes' },
  { id: 2, when: '2026-11-11T15:02:00', userName: 'admin', entity: 'Employee', entityId: '14', action: 'Deactivated', summary: 'Owais Qureshi deactivated' },
  { id: 3, when: '2026-11-10T09:40:00', userName: 'admin', entity: 'Shift', entityId: '3', action: 'Created', summary: 'Night shift created' },
]

// ---------- fake daily results ----------

function seeded(a, b) {
  // small repeatable "random" number between 0 and 1 based on employee and date
  let h = (a * 2654435761) ^ b
  h = Math.imul(h ^ (h >>> 15), 2246822519)
  h = Math.imul(h ^ (h >>> 13), 3266489917)
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295
}
const dateNumber = (d) => Number(d.replaceAll('-', ''))
const hhmm = (mins) => String(Math.floor(mins / 60) % 24).padStart(2, '0') + ':' + String(mins % 60).padStart(2, '0')
const toMins = (t) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5))
const weekday = (d) => ((new Date(d + 'T00:00:00').getDay() + 6) % 7) + 1

function shiftFor(emp, date) {
  const a = assignments.find((x) => x.employeeId === emp.id && x.fromDate <= date && (!x.toDate || x.toDate >= date))
  const shift = a && shifts.find((s) => s.id === a.shiftId)
  if (!shift || !shift.workingDays.includes(weekday(date))) return null
  return shift
}

function dailyRow(emp, date) {
  const dept = departments.find((d) => d.id === emp.departmentId)
  const base = {
    employeeId: emp.id, employeeCode: emp.employeeCode, employeeName: emp.name,
    department: dept ? dept.name : '', date,
  }
  const shift = shiftFor(emp, date)
  if (!shift) return { ...base, shiftName: null, status: 'NoShift', alertCount: 0 }

  const r = seeded(emp.id, dateNumber(date))
  const start = toMins(shift.startTime)
  const end = toMins(shift.endTime) + (shift.isOvernight ? 1440 : 0)
  if (r < 0.1) {
    return { ...base, shiftName: shift.name, status: 'Absent', alertCount: 1, breakMinutes: 0, presenceMinutes: 0, workMinutes: 0, overtimeMinutes: 0, shortfallMinutes: 0, shiftHoursStatus: 'None' }
  }
  const late = r > 0.75 ? Math.round(seeded(emp.id, 7) * 40) : 0
  const early = r > 0.55 && r < 0.65 ? 45 : 0
  const missingOut = r > 0.1 && r < 0.17
  const checkIn = start + late - 3
  const checkOut = end - early + (r > 0.9 ? 70 : 4)
  const presence = checkOut - checkIn
  const work = missingOut ? 0 : presence - shift.breakMinutes
  const planned = end - start - shift.breakMinutes
  const overtime = Math.max(0, work - planned)
  const shortfall = missingOut ? 0 : Math.max(0, planned - work)
  const alerts = (late > settings.gracePeriodMinutes ? 1 : 0) + (early ? 1 : 0) + (missingOut ? 1 : 0)
  return {
    ...base,
    shiftName: shift.name,
    status: missingOut ? 'MissingCheckOut' : late > settings.gracePeriodMinutes ? 'Late' : early ? 'EarlyExit' : 'Present',
    checkIn: hhmm(checkIn),
    checkOut: missingOut ? null : hhmm(checkOut),
    breakMinutes: missingOut ? 0 : shift.breakMinutes,
    presenceMinutes: missingOut ? 0 : presence,
    workMinutes: work,
    overtimeMinutes: overtime,
    shortfallMinutes: shortfall,
    shiftHoursStatus: missingOut ? 'Unknown' : shortfall > settings.gracePeriodMinutes ? 'Short' : overtime > settings.gracePeriodMinutes ? 'Over' : 'Met',
    alertCount: alerts,
  }
}

function dayDetail(emp, date) {
  const row = dailyRow(emp, date)
  const shift = shiftFor(emp, date)
  const detail = {
    employee: { id: emp.id, employeeCode: emp.employeeCode, name: emp.name, department: row.department },
    date,
    shift: shift ? { name: shift.name, startTime: shift.startTime, endTime: shift.endTime, breakMinutes: shift.breakMinutes, isOvernight: shift.isOvernight } : null,
    settingsUsed: { gracePeriodMinutes: settings.gracePeriodMinutes, flexiTimeCover: settings.flexiTimeCover, calculatedAt: date + 'T23:55:00' },
    rawPunches: [], events: [], breaks: [], alerts: [],
    summary: row,
  }
  if (!row.checkIn) return detail
  const mid = toMins(shift.startTime) + 240
  const punches = [
    { time: row.checkIn, deviceName: 'Main gate IN', direction: 'IN', floor: 'Ground' },
    { time: hhmm(mid), deviceName: 'Canteen OUT', direction: 'OUT', floor: 'Ground' },
    { time: hhmm(mid + shift.breakMinutes), deviceName: 'Canteen IN', direction: 'IN', floor: 'Ground' },
  ]
  if (row.checkOut) punches.push({ time: row.checkOut, deviceName: 'Main gate OUT', direction: 'OUT', floor: 'Ground' })
  detail.rawPunches = punches
  detail.events = punches.map((p, i) => ({
    time: p.time, deviceName: p.deviceName,
    type: i === 0 ? 'CheckIn' : i === 1 ? 'BreakStart' : i === 2 ? 'BreakEnd' : 'CheckOut',
  }))
  detail.breaks = [{ start: hhmm(mid), end: hhmm(mid + shift.breakMinutes), minutes: shift.breakMinutes }]
  if (row.status === 'Late') detail.alerts.push({ type: 'LateArrival', time: row.checkIn, message: 'Checked in after the grace period' })
  if (row.status === 'EarlyExit') detail.alerts.push({ type: 'EarlyExit', time: row.checkOut, message: 'Checked out before the shift end' })
  if (row.status === 'MissingCheckOut') detail.alerts.push({ type: 'MissingCheckOut', time: null, message: 'No check-out punch found' })
  return detail
}

function dailyReport(date, departmentId) {
  return employees
    .filter((e) => e.isActive && (!departmentId || e.departmentId === Number(departmentId)))
    .map((e) => dailyRow(e, date))
    .filter((r) => r.status !== 'NoShift')
}

function addDays(date, n) {
  const d = new Date(date + 'T00:00:00')
  d.setDate(d.getDate() + n)
  return d.toISOString().slice(0, 10)
}

function dashboard(date) {
  const count = (rows) => ({
    present: rows.filter((r) => r.status !== 'Absent').length,
    absent: rows.filter((r) => r.status === 'Absent').length,
    late: rows.filter((r) => r.status === 'Late').length,
    earlyExit: rows.filter((r) => r.status === 'EarlyExit').length,
    missingCheckOut: rows.filter((r) => r.status === 'MissingCheckOut').length,
  })
  const rows = dailyReport(date)
  const trend = []
  for (let i = 29; i >= 0; i--) {
    const d = addDays(date, -i)
    const c = count(dailyReport(d))
    trend.push({ date: d, present: c.present, absent: c.absent, late: c.late })
  }
  const total = count(rows)
  return {
    date,
    totals: total,
    byDepartment: departments.map((d) => ({ department: d.name, ...count(rows.filter((r) => r.department === d.name)) })),
    trend,
    openAlertsByType: [
      { type: 'LateArrival', count: total.late },
      { type: 'EarlyExit', count: total.earlyExit },
      { type: 'MissingCheckOut', count: total.missingCheckOut },
      { type: 'AbsentWithShift', count: total.absent },
    ],
  }
}

function employeePeriod(employeeId, from, to) {
  const emp = employees.find((e) => e.id === Number(employeeId))
  if (!emp) throw new Error('Employee not found')
  const days = []
  for (let d = from; d <= to; d = addDays(d, 1)) {
    const row = dailyRow(emp, d)
    if (row.status !== 'NoShift') days.push(row)
  }
  const sum = (key) => days.reduce((t, r) => t + (r[key] || 0), 0)
  return {
    employee: { id: emp.id, employeeCode: emp.employeeCode, name: emp.name },
    from, to, days,
    totals: {
      daysWorked: days.filter((r) => r.status !== 'Absent').length,
      workMinutes: sum('workMinutes'),
      overtimeMinutes: sum('overtimeMinutes'),
      shortfallMinutes: sum('shortfallMinutes'),
      breakMinutes: sum('breakMinutes'),
      lateArrivals: days.filter((r) => r.status === 'Late').length,
      earlyExits: days.filter((r) => r.status === 'EarlyExit').length,
      missingPunches: days.filter((r) => r.status === 'MissingCheckOut').length,
    },
  }
}

// ---------- router ----------

function withDepartmentName(e) {
  const d = departments.find((x) => x.id === e.departmentId)
  return { ...e, departmentName: d ? d.name : '', status: e.isActive ? 'Active' : 'Inactive' }
}

export async function mockRequest(method, path, params = {}, body = {}) {
  await wait(250)
  let m

  if (path === '/auth/login') {
    if (body.userName === 'admin' && body.password === 'admin') {
      return { token: 'demo-token', expiresAt: null, user: { id: '1', userName: 'admin', displayName: 'Demo Admin', roles: ['Admin'] } }
    }
    const err = new Error('Wrong user name or password.')
    err.status = 401
    throw err
  }
  if (path === '/auth/me') return { id: '1', userName: 'admin', displayName: 'Demo Admin', roles: ['Admin'] }

  // employees
  if (path === '/employees' && method === 'GET') {
    const q = (params.search || '').toLowerCase()
    let list = employees.filter((e) =>
      (!q || e.name.toLowerCase().includes(q) || e.employeeCode.toLowerCase().includes(q) || e.deviceUserId.includes(q)) &&
      (!params.departmentId || e.departmentId === Number(params.departmentId)) &&
      (!params.status || (params.status === 'Active') === e.isActive))
    const total = list.length
    const size = Number(params.pageSize) || 20
    const page = Number(params.page) || 1
    list = list.slice((page - 1) * size, page * size)
    return { items: list.map(withDepartmentName), total }
  }
  if (path === '/employees' && method === 'POST') {
    if (employees.some((e) => e.employeeCode === body.employeeCode)) {
      const err = new Error('Employee code already exists.')
      err.status = 400
      throw err
    }
    const e = { ...body, id: nextId++, departmentId: Number(body.departmentId), isActive: true }
    employees.push(e)
    return withDepartmentName(e)
  }
  if ((m = path.match(/^\/employees\/(\d+)$/))) {
    const e = employees.find((x) => x.id === Number(m[1]))
    if (method === 'GET') return withDepartmentName(e)
    if (method === 'PUT') {
      Object.assign(e, body, { departmentId: Number(body.departmentId) })
      return withDepartmentName(e)
    }
  }
  if ((m = path.match(/^\/employees\/(\d+)\/(deactivate|reactivate)$/))) {
    const e = employees.find((x) => x.id === Number(m[1]))
    e.isActive = m[2] === 'reactivate'
    return withDepartmentName(e)
  }

  // departments
  if (path === '/departments' && method === 'GET') {
    return departments.map((d) => ({ ...d, employeeCount: employees.filter((e) => e.departmentId === d.id && e.isActive).length }))
  }
  if (path === '/departments' && method === 'POST') {
    const d = { id: nextId++, name: body.name, isActive: true }
    departments.push(d)
    return d
  }
  if ((m = path.match(/^\/departments\/(\d+)$/)) && method === 'PUT') {
    departments.find((d) => d.id === Number(m[1])).name = body.name
    return null
  }
  if ((m = path.match(/^\/departments\/(\d+)\/(deactivate|activate)$/))) {
    departments.find((d) => d.id === Number(m[1])).isActive = m[2] === 'activate'
    return null
  }

  // shifts
  if (path === '/shifts' && method === 'GET') return shifts
  if (path === '/shifts' && method === 'POST') {
    const s = { ...body, id: nextId++, isOvernight: body.endTime < body.startTime }
    shifts.push(s)
    return s
  }
  if ((m = path.match(/^\/shifts\/(\d+)$/)) && method === 'PUT') {
    const s = shifts.find((x) => x.id === Number(m[1]))
    Object.assign(s, body, { isOvernight: body.endTime < body.startTime })
    return s
  }
  if (path === '/shift-assignments' && method === 'GET') {
    return assignments
      .filter((a) => a.employeeId === Number(params.employeeId))
      .map((a) => ({ ...a, shiftName: shifts.find((s) => s.id === a.shiftId).name }))
  }
  if (path === '/shift-assignments' && method === 'POST') {
    const clash = assignments.some((a) => a.employeeId === Number(body.employeeId) &&
      a.fromDate <= (body.toDate || '9999-12-31') && (a.toDate || '9999-12-31') >= body.fromDate)
    if (clash) {
      const err = new Error('This employee already has a shift in that date range.')
      err.status = 409
      throw err
    }
    const a = { id: nextId++, employeeId: Number(body.employeeId), shiftId: Number(body.shiftId), fromDate: body.fromDate, toDate: body.toDate || null }
    assignments.push(a)
    return a
  }
  if (path === '/shift-assignments/bulk') {
    const targets = body.employeeIds ? body.employeeIds.map(Number) : employees.filter((e) => e.isActive && e.departmentId === Number(body.departmentId)).map((e) => e.id)
    const skipped = []
    let assigned = 0
    targets.forEach((id) => {
      const clash = assignments.some((a) => a.employeeId === id && a.fromDate <= (body.toDate || '9999-12-31') && (a.toDate || '9999-12-31') >= body.fromDate)
      if (clash) {
        const e = employees.find((x) => x.id === id)
        skipped.push({ employeeId: id, employeeName: e.name, reason: 'Already has a shift in that range' })
      } else {
        assignments.push({ id: nextId++, employeeId: id, shiftId: Number(body.shiftId), fromDate: body.fromDate, toDate: body.toDate || null })
        assigned++
      }
    })
    return { assigned, skipped }
  }
  if ((m = path.match(/^\/shift-assignments\/(\d+)$/)) && method === 'DELETE') {
    assignments = assignments.filter((a) => a.id !== Number(m[1]))
    return null
  }

  // settings and analysis
  if (path === '/settings' && method === 'GET') return settings
  if (path === '/settings' && method === 'PUT') {
    settings = { gracePeriodMinutes: Number(body.gracePeriodMinutes), flexiTimeCover: !!body.flexiTimeCover }
    return settings
  }
  if (path === '/analysis/run') return { daysAnalyzed: 42, daysSkippedNoShift: 6 }

  // reports
  if (path === '/reports/daily') return dailyReport(params.date, params.departmentId)
  if ((m = path.match(/^\/reports\/daily\/(\d+)\/([\d-]+)$/))) {
    return dayDetail(employees.find((e) => e.id === Number(m[1])), m[2])
  }
  if (path === '/reports/employee-period') return employeePeriod(params.employeeId, params.from, params.to)
  if (path === '/reports/dashboard') return dashboard(params.date)

  // punches, devices, audit
  if (path === '/punches/unmapped') {
    return [
      { id: 1, deviceName: 'Main gate IN', deviceUserId: '999', time: params.to + 'T08:52:00', direction: 'IN', floor: 'Ground' },
      { id: 2, deviceName: 'Warehouse IN', deviceUserId: '1042', time: params.to + 'T06:01:00', direction: 'IN', floor: 'Ground' },
    ]
  }
  if (path === '/punches/unscheduled') {
    const e = employees[2]
    return [{ id: 3, employeeId: e.id, employeeCode: e.employeeCode, employeeName: e.name, date: params.to, time: params.to + 'T10:15:00', deviceName: 'Main gate IN', direction: 'IN' }]
  }
  if (path === '/devices/status') {
    return [
      { id: 1, name: 'Main gate IN', ip: '192.168.1.201', direction: 'IN', floor: 'Ground', enabled: true, lastSuccessfulSync: '2026-11-13T14:30:00', lastError: null, punchesToday: 188, clockDriftSeconds: 4 },
      { id: 2, name: 'Main gate OUT', ip: '192.168.1.202', direction: 'OUT', floor: 'Ground', enabled: true, lastSuccessfulSync: '2026-11-13T14:30:00', lastError: null, punchesToday: 41, clockDriftSeconds: -2 },
      { id: 3, name: 'Warehouse IN', ip: '192.168.1.210', direction: 'IN', floor: 'Ground', enabled: true, lastSuccessfulSync: '2026-11-13T11:00:00', lastError: 'Connection timed out', punchesToday: 63, clockDriftSeconds: 95 },
    ]
  }
  if (path === '/audit-log') {
    const items = auditLog.filter((a) => !params.entity || a.entity === params.entity)
    return { items, total: items.length }
  }

  throw new Error('Mock has no handler for ' + method + ' ' + path)
}
