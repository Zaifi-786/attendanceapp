import { http } from './http'

// ANL-3: run the analysis on demand (SET-3 and ANL-5: this replaces the stored results)
// POST /api/analysis/run
//   body: { employeeId, fromDate, toDate }   employeeId is optional, empty means everyone
//   -> { daysAnalyzed, daysSkippedNoShift }
export const runAnalysis = (data) => http.post('/analysis/run', data)
