import { http } from './http'

// EMP-3: GET /api/employees?search=&departmentId=&status=&page=&pageSize=
//   status is 'Active' or 'Inactive' (leave empty for all)
//   -> { items: [Employee], total }
export const listEmployees = (params) => http.get('/employees', params)

// GET /api/employees/{id}
export const getEmployee = (id) => http.get(`/employees/${id}`)

// EMP-1: POST /api/employees
//   body: { employeeCode, name, departmentId, joinDate, deviceUserId }
export const createEmployee = (data) => http.post('/employees', data)

// EMP-2 and DEP-2: PUT /api/employees/{id}  (changing departmentId moves the employee)
export const updateEmployee = (id, data) => http.put(`/employees/${id}`, data)

// EMP-2: employees are never deleted, only switched off and on
// POST /api/employees/{id}/deactivate
// POST /api/employees/{id}/reactivate
export const deactivateEmployee = (id) => http.post(`/employees/${id}/deactivate`)
export const reactivateEmployee = (id) => http.post(`/employees/${id}/reactivate`)
