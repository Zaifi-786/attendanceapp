import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getMe, login as loginRequest } from '../api/auth'
import { setUnauthorizedHandler, tokenStore } from '../api/http'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const navigate = useNavigate()
  const [user, setUser] = useState(null)
  // true while we check a saved token on first load
  const [checking, setChecking] = useState(Boolean(tokenStore.get()))

  const clearSession = useCallback(() => {
    tokenStore.clear()
    setUser(null)
  }, [])

  // if any API call comes back 401, go to sign-in
  useEffect(() => {
    setUnauthorizedHandler(() => {
      clearSession()
      navigate('/login', { replace: true, state: { expired: true } })
    })
  }, [clearSession, navigate])

  // page refresh: ask the API who we are
  useEffect(() => {
    if (!tokenStore.get()) return
    getMe()
      .then((u) => setUser(u))
      .catch(() => clearSession())
      .finally(() => setChecking(false))
  }, [clearSession])

  async function login(userName, password) {
    const result = await loginRequest(userName, password)
    // AUTH-1: the API should already refuse non-admins, this is a second check
    if (!result.user.roles || !result.user.roles.includes('Admin')) {
      throw new Error('Only administrators can sign in.')
    }
    tokenStore.set(result.token)
    setUser(result.user)
  }

  function logout() {
    clearSession()
    // AUTH-3: nothing should stay behind after sign-out
    sessionStorage.clear()
    navigate('/login', { replace: true })
  }

  return (
    <AuthContext.Provider value={{ user, checking, login, logout }}>{children}</AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
