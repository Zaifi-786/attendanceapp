// minutes -> "7h 30m". Empty or zero shows a dash.
export function fmtMinutes(mins) {
  if (mins === null || mins === undefined) return '-'
  if (mins === 0) return '0m'
  const sign = mins < 0 ? '-' : ''
  const abs = Math.abs(mins)
  const h = Math.floor(abs / 60)
  const m = abs % 60
  if (h === 0) return `${sign}${m}m`
  return `${sign}${h}h ${String(m).padStart(2, '0')}m`
}

export function toISODate(d) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export const today = () => toISODate(new Date())

export function monthRange(date = new Date()) {
  const first = new Date(date.getFullYear(), date.getMonth(), 1)
  const last = new Date(date.getFullYear(), date.getMonth() + 1, 0)
  return { from: toISODate(first), to: toISODate(last) }
}

// "2026-11-13" -> "13 Nov 2026"
export function fmtDate(iso) {
  if (!iso) return '-'
  const d = new Date(iso.slice(0, 10) + 'T00:00:00')
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
}

export function fmtDateTime(iso) {
  if (!iso) return '-'
  const d = new Date(iso)
  return d.toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

// "2026-11-13T08:52:00" -> "08:52"
export const fmtTime = (iso) => (iso ? iso.slice(11, 16) : '-')

export const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

// "LateArrival" -> "Late arrival"
export function nice(text) {
  if (!text) return '-'
  const spaced = text.replace(/([a-z])([A-Z])/g, '$1 $2')
  return spaced.charAt(0).toUpperCase() + spaced.slice(1).toLowerCase()
}
