import { useCallback, useEffect, useRef, useState } from 'react'

// Runs an API call when the page opens and again whenever `deps` change.
// Pass null as the function to skip loading (for example while a filter is still empty).
export default function useFetch(fn, deps = []) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(Boolean(fn))
  const [error, setError] = useState('')
  const fnRef = useRef(fn)
  fnRef.current = fn
  const counter = useRef(0)

  const load = useCallback(async () => {
    if (!fnRef.current) {
      setData(null)
      setLoading(false)
      return
    }
    const myCall = ++counter.current
    setLoading(true)
    setError('')
    try {
      const result = await fnRef.current()
      if (myCall === counter.current) setData(result)
    } catch (e) {
      if (myCall === counter.current) setError(e.message || 'Something went wrong')
    } finally {
      if (myCall === counter.current) setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return { data, loading, error, reload: load, setData }
}
